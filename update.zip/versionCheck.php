<?php
$localVersionFile = __DIR__ . '/version.txt';
$onlineVersionUrl = 'https://raw.githubusercontent.com/Tommy0412/embedsito/master/version.txt';

function getLocalVersion($filePath) {
    if (!file_exists($filePath)) {
        throw new Exception("Local version file not found: $filePath");
    }
    $version = trim(file_get_contents($filePath));
    if (empty($version)) {
        throw new Exception("Local version file is empty.");
    }
    return $version;
}

function getOnlineVersion($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FAILONERROR, true);
    $version = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpStatus !== 200) {
        throw new Exception("Failed to fetch online version. HTTP Status: $httpStatus");
    }

    $version = trim($version);
    if (empty($version)) {
        throw new Exception("Online version file is empty.");
    }
    return $version;
}

header('Content-Type: application/json');

try {
    $localVersion = getLocalVersion($localVersionFile);
    $onlineVersion = getOnlineVersion($onlineVersionUrl);
    echo json_encode([
        'isUpdateAvailable' => version_compare($onlineVersion, $localVersion, '>'),
        'localVersion' => $localVersion,
        'onlineVersion' => $onlineVersion
    ]);
} catch (Exception $e) {
    echo json_encode([
        'isUpdateAvailable' => false,
        'localVersion' => 'N/A',
        'onlineVersion' => 'N/A',
        'error' => $e->getMessage()
    ]);
}
?>