<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

$id      = $_GET['id']      ?? '';
$season  = $_GET['season']  ?? '';
$episode = $_GET['episode'] ?? '';

if (!$id) {
    die("Missing ID");
}

function getCurrentBaseUrl() {
		$scheme = 'http://';

if (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') ||
    (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
) {
    $scheme = 'https://';
}
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    return "$scheme$host$path/";
}

$baseUrl = getCurrentBaseUrl();
$imageUrl = $baseUrl . 'image.php?id=' . urlencode($id);
if ($season !== null && $episode !== null) {
    $imageUrl .= '&season=' . urlencode($season) . '&episode=' . urlencode($episode);
}
$imageUrl .= '&raw=1';
$apiUrl = $baseUrl . "moviebox1.php?id=$id";
if ($season !== '' && $episode !== '') {
    $apiUrl .= "&season=" . urlencode($season) . "&episode=" . urlencode($episode);
}

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false
]);
$response = curl_exec($ch);
if (curl_errno($ch)) {
    //die("cURL error: " . curl_error($ch));
}
curl_close($ch);

$data = json_decode($response, true);
if (!$data || !isset($data['streams'])) {
    //die("Invalid or missing data");
}

$sources = [];
foreach ($data['streams'] as $label => $stream) {
    $sources[] = [
        "file"  => $stream['url'],
        "label" => $label . "p",
        "type"  => "mp4"
    ];
}

usort($sources, function ($a, $b) {
    return (int)$a['label'] - (int)$b['label'];
});


$tracks = [];
if (!empty($data['captions'])) {
    foreach ($data['captions'] as $caption) {
        $tracks[] = [
            "file"    => $caption['url'],
            "label"   => $caption['lan'],
            "kind"    => "captions",
            "default" => ($caption['lan'] === 'en') 
        ];
    }
}

$sources_json  = json_encode($sources, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
$subtitles_all = !empty($tracks) ? json_encode($tracks, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) : '';
$videoId = "moviebox" . $id;

if (!empty($season) && !empty($episode)) {
    $videoId = "moviebox" . $id . $season . $episode;
}
?>
<?php if (isset($data['streams'])) { ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Player</title>
<style>
  #player {
    position: absolute;
    width: 100% !important;
    height: 100% !important;
  }
</style>
<link rel="stylesheet" href="netflix.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="jwplayer.js"></script>
<script type="text/javascript">jwplayer.key="Ywok59g9j93GtuSU7+axNzjIp/TBfiK4s0vvYg==";</script>
<script disable-devtool-auto src="https://cdn.jsdelivr.net/npm/disable-devtool@latest"></script>
</head>
<body>
<div id="player"></div>
<div id="resume-container" style="display: none; background: rgba(0,0,0,0.9); color: white; padding: 30px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; border-radius: 12px; border: 2px solid #ffd700; box-shadow: 0 0 20px rgba(255,215,0,0.3);">
    <p style="color: #ffd700; font-size: 24px; font-weight: bold; margin: 0 0 15px 0;">You previously watched this video. Resume from where you left off?</p>
    <p style="color: #ffd700; font-size: 20px; margin: 0 0 25px 0;">Time: <span id="resume-time" style="font-weight: bold;"></span></p>
    <button id="resume-btn" style="background: #007bff; color: white; border: none; padding: 12px 25px; margin: 5px; cursor: pointer; border-radius: 6px; font-size: 18px; margin-right: 15px;">Resume</button>
    <button id="skip-btn" style="background: #6c757d; color: white; border: none; padding: 12px 25px; margin: 5px; cursor: pointer; border-radius: 6px; font-size: 18px;">Skip</button>
</div>
<script type="text/javascript">
 const playerInstance = jwplayer("player").setup({
  controls: true,
  sharing: false,
  displaytitle: false,

  skin: {
    name: "netflix"
  },  
     sources: <?php echo $sources_json; ?>,
	 image: "<?php echo $imageUrl; ?>",
	 primary: 'html5',
     preload: 'none',
     <?php if (!empty($subtitles_all)) { ?>
    tracks: <?php echo $subtitles_all; ?>,
    captions: {
        color: '#FFFF00',
        fontOpacity: 100,
        edgeStyle: "none",
        backgroundColor: "#000000",
        windowColor: "#000000",
        windowOpacity: 0,
        backgroundOpacity: 100,
        fontFamily: 'Arial',
        fontSize: 20
    },
	<?php } ?>
});

const videoKey = "video_progress_<?php echo md5($videoId); ?>";

function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return [
        h,
        m > 9 ? m : (h ? '0' + m : m || '0'),
        s > 9 ? s : '0' + s
    ].filter(Boolean).join(':');
}

playerInstance.on("ready", function () {
  const playerContainer = playerInstance.getContainer();
  const buttonContainer = playerContainer.querySelector(".jw-button-container");
  const spacer = buttonContainer.querySelector(".jw-spacer");
  const timeSlider = playerContainer.querySelector(".jw-slider-time");
  buttonContainer.replaceChild(timeSlider, spacer);

  const rewindContainer = playerContainer.querySelector(".jw-display-icon-rewind");
  const forwardContainer = rewindContainer.cloneNode(true);
  const forwardDisplayButton = forwardContainer.querySelector(".jw-icon-rewind");
  forwardDisplayButton.style.transform = "scaleX(-1)";
  forwardDisplayButton.ariaLabel = "Forward 10 Seconds";
  const nextContainer = playerContainer.querySelector(".jw-display-icon-next");
  nextContainer.parentNode.insertBefore(forwardContainer, nextContainer);

  playerContainer.querySelector(".jw-display-icon-next").style.display = "none";
  const rewindControlBarButton = buttonContainer.querySelector(".jw-icon-rewind");
  const forwardControlBarButton = rewindControlBarButton.cloneNode(true);
  forwardControlBarButton.style.transform = "scaleX(-1)";
  forwardControlBarButton.ariaLabel = "Forward 10 Seconds";
  rewindControlBarButton.parentNode.insertBefore(
    forwardControlBarButton,
    rewindControlBarButton.nextElementSibling
  );

  [forwardDisplayButton, forwardControlBarButton].forEach((button) => {
    button.onclick = () => {
      playerInstance.seek(playerInstance.getPosition() + 10);
    };
  });

  const savedPosition = localStorage.getItem(videoKey);
  if (savedPosition) {
    const position = parseFloat(savedPosition);
    const resumeContainer = document.getElementById('resume-container');
    const resumeTime = document.getElementById('resume-time');
    const resumeBtn = document.getElementById('resume-btn');
    const skipBtn = document.getElementById('skip-btn');
    
    resumeTime.textContent = formatTime(position);
    resumeContainer.style.display = 'block';
    
    resumeBtn.onclick = function() {
      playerInstance.seek(position);
      resumeContainer.style.display = 'none';
    };
    
    skipBtn.onclick = function() {
      resumeContainer.style.display = 'none';
    };
  }
});

playerInstance.on("time", function(event) {
  if (event.position > 0) {
    localStorage.setItem(videoKey, event.position);
  }
});

playerInstance.on("complete", function() {
  localStorage.removeItem(videoKey);
});
</script>
</body>
</html>
<?php } else { ?>
    <div style="
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #1a1a1a;
    ">
        <div style="
            padding: 20px 40px;
            background: rgba(255, 255, 0, 0.1);
            border: 2px solid #FFF000;
            border-radius: 8px;
            font-size: 1.5rem;
            font-weight: bold;
            color: #FFF000;
            text-shadow: 1px 1px 3px black;
        ">
            NOT FOUND!
        </div>
    </div>
<?php } ?>