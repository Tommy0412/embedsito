<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

set_time_limit(0);

$tmdbApiKey = '05902896074695709d7763505bb88b4d';
$zoechipBaseUrl = 'https://zoechip.org';
$tmdbApiUrl = 'https://api.themoviedb.org/3/movie/';

function getTmdbShowTitle($tmdbId, $tmdbApiKey) {
    $url = "https://api.themoviedb.org/3/tv/$tmdbId?api_key=$tmdbApiKey&language=en-US";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200) {
        $data = json_decode($response, true);
        return $data['name'] ?? null;
    } else {
        throw new Exception("tv show not found on TMDB.");
    }
}

function getMovieFromTmdb($tmdbId, $tmdbApiKey) {
    global $tmdbApiUrl;

    $url = $tmdbApiUrl . $tmdbId . '?api_key=' . $tmdbApiKey;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return null; 
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        error_log("HTTP error: $httpCode for URL: $url");
        return null; 
    }

    $movieData = json_decode($response, true);

    if (isset($movieData['title']) && isset($movieData['release_date'])) {
        $year = substr($movieData['release_date'], 0, 4);
        $titleWithYear = $movieData['title'] . " (" . $year . ")";
        return $titleWithYear;
    } else {
        error_log("Movie not found on TMDB for ID: $tmdbId");
        return null;
    }
}

function generateSlug($title, $season, $episode) {
    $slugTitle = preg_replace('/[^a-z0-9]+/', '-', strtolower(trim($title)));
    return "{$slugTitle}-season-{$season}-episode-{$episode}";
}

function searchMovieOnZoechip($titleWithYear, $zoechipBaseUrl) {
    $searchUrl = $zoechipBaseUrl . '/?s=' . urlencode($titleWithYear);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $searchUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        //throw new Exception("Error fetching data from Zoechip.");
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        error_log("HTTP error: $httpCode for URL: $searchUrl");
        //throw new Exception("Error fetching data from Zoechip.");
    }

    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    @$doc->loadHTML($response);
    libxml_clear_errors();

    $xpath = new DOMXPath($doc);
    $films = $xpath->query("//div[@class='film_list-wrap']//div[@class='flw-item']");

    foreach ($films as $film) {
        $titleNode = $xpath->query(".//h3[@class='film-name']/a", $film)->item(0);
        if ($titleNode) {
            $filmTitle = trim($titleNode->getAttribute('title'));
            if ($filmTitle === $titleWithYear) {
                $filmUrl = $titleNode->getAttribute('href');
                return $filmUrl;
            }
        }
    }

    throw new Exception("Exact match not found");
}

function getFinalUrl($url, $referer, $origin) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Referer: $referer",
        "Origin: $origin"
    ]);
    curl_exec($ch);
    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL); 
    curl_close($ch);
    
    return $finalUrl;
}

function getHostnameFromUrl($url) {
    $parsedUrl = parse_url($url);
    return $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
}

function fetchDataWithCurl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        error_log("HTTP error: $httpCode for URL: $url");
        return false;
    }

    return $response;
}

function sendPostRequestWithCurl($url, $postData, $referer) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-type: application/x-www-form-urlencoded",
        "X-Requested-With: XMLHttpRequest",
        "Referer: $referer",
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        error_log("HTTP error: $httpCode for URL: $url");
        return false;
    }

    return $response;
}

function getFinalUrlWithCurl($url, $referer) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true); 
    curl_setopt($ch, CURLOPT_NOBODY, true); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_REFERER, $referer);

    curl_exec($ch);

    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    return $finalUrl;
}

try {
    $tmdbId = isset($_GET['tmdb']) ? htmlspecialchars(trim($_GET['tmdb'])) : null;
    $season = isset($_GET['season']) ? htmlspecialchars(trim($_GET['season'])) : null;
    $episode = isset($_GET['episode']) ? htmlspecialchars(trim($_GET['episode'])) : null;

    if (!$tmdbId) {
        die('TMDB ID is required.');
    }

    if (isset($season) && !empty($season) && isset($episode) && !empty($episode)) {
        $showTitle = getTmdbShowTitle($tmdbId, $tmdbApiKey);
        $slug = generateSlug($showTitle, $season, $episode);
        $zoechipUrl = "$zoechipBaseUrl/episode/$slug/";
    } else {
        $movieTitleWithYear = getMovieFromTmdb($tmdbId, $tmdbApiKey);
        $zoechipUrl = searchMovieOnZoechip($movieTitleWithYear, $zoechipBaseUrl);
    }

    $response = fetchDataWithCurl($zoechipUrl);

    if ($response) {
        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        @$doc->loadHTML($response);
        libxml_clear_errors();

        $xpath = new DOMXPath($doc);
        $movieIdNode = $xpath->query("//div[@id='show_player_ajax']")->item(0);
        $mid = $movieIdNode ? $movieIdNode->getAttribute("movie-id") : null;

        if (!$mid) {
            throw new Exception("No movie ID found.");
        }

        $postData = http_build_query([
            'action' => 'lazy_player',
            'movieID' => $mid,
        ]);

        $ajaxUrl = "$zoechipBaseUrl/wp-admin/admin-ajax.php";
        $serverResponse = sendPostRequestWithCurl($ajaxUrl, $postData, $zoechipUrl);

        @$doc->loadHTML($serverResponse);
        $xpath = new DOMXPath($doc);

        $links = $xpath->query("//ul[@class='nav']//a");
        $servers = [];
        $serverNamesToMatch = ['Filemoon', 'Netu.tv', 'Doodstream'];

        foreach ($links as $link) {
            $span = $link->getElementsByTagName('span')->item(0);
            if ($span) {
                $serverName = trim($span->nodeValue);
                $serverUrl = $link->getAttribute("data-server");

                if (in_array($serverName, $serverNamesToMatch)) {
                    $servers[$serverName] = $serverUrl;
                }
            }
        }

        $filemoon = isset($servers['Filemoon']) ? getFinalUrlWithCurl($servers['Filemoon'], $zoechipUrl) : "";
        $netu = isset($servers['Netu.tv']) ? getFinalUrlWithCurl($servers['Netu.tv'], $zoechipUrl) : "";
        $dood = isset($servers['Doodstream']) ? getFinalUrlWithCurl($servers['Doodstream'], $zoechipUrl) : "";

        $dataset = [
            "filemoon" => $filemoon,
            "netu.tv" => $netu,
            "doodstream" => $dood,
        ];

        header('Content-Type: application/json');
        echo json_encode($dataset, JSON_PRETTY_PRINT);
        exit();
    } else {
        throw new Exception("Failed to fetch Zoechip page content.");
    }
} catch (Exception $e) {
    echo $e->getMessage();
}

?>