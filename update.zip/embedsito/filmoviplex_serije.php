<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serije</title>
    <meta name="robots" content="noindex,nofollow">
    <style type="text/css">
        html {
            overflow: auto;
        }
        html, body, iframe {
            margin: 0;
            padding: 0;
            height: 100%;
            border: none;
        }
        iframe {
            display: block;
            width: 100%;
            border: none;
            overflow-y: auto;
            overflow-x: hidden;
        }
    </style>
</head>
<body>
    <?php
	$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $NEW_IFRAME_BASE = "{$protocol}{$host}/embedsito/netu/index.php?file=";
	
    function getQueryParams() {
        return [
            'tmdbId' => isset($_GET['tmdb']) ? $_GET['tmdb'] : null,
            'season' => isset($_GET['season']) ? $_GET['season'] : null,
            'episode' => isset($_GET['episode']) ? $_GET['episode'] : null
        ];
    }

    function decodeBase64($str) {
        return urldecode(base64_decode($str));
    }

    function replaceHost($url, $newHost) {
        $parsedUrl = parse_url($url);
        return $parsedUrl['scheme'] . '://' . $newHost . $parsedUrl['path'] . (isset($parsedUrl['query']) ? '?' . $parsedUrl['query'] : '');
    }
    
	function fetchData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
    }
	
	function fetchDataWithCurl($url, $headers = []) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $response = curl_exec($ch);
    curl_close($ch);
    return $response ? $response : null;
   }
	
    function fetchTvShowDetails($tmdbId) {
        $apiKey = '05902896074695709d7763505bb88b4d';
        $url = "https://api.themoviedb.org/3/tv/$tmdbId?api_key=$apiKey";
		$response = fetchData($url);
        $data = json_decode($response, true);
        return [
            'title' => $data['name'],
            'year' => date('Y', strtotime($data['first_air_date']))
        ];
    }

function searchFilmoviplexTVShow($fullTitle) {
    $search = urlencode($fullTitle);
    $url = "https://www.filmoviplex.com/?all=all&s=$search&orderby=serije";

    $headers = [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Referer: https://filmoviplex.com/',
        'Origin: https://filmoviplex.com'
    ];

    $response = fetchDataWithCurl($url, $headers);

    if (preg_match_all('#<a[^>]+title="([^"]+)"[^>]+href="([^"]+)"#i', $response, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $titleAttr = trim($match[1]);
            $href = trim($match[2]);

            if (strcasecmp($titleAttr, $fullTitle) === 0) {
                return $href;
            }
        }
    }

    return null;
}

    function extractIframeUrl($htmlContent, $season, $episode) {
        $regex = "/.openload{$season}_{$episode}.*?src='([^']+)'/";
        if (preg_match($regex, $htmlContent, $matches)) {
            return $matches[1];
        }
        return null;
    }

    function fetchAndInsertIframe() {
		global $NEW_IFRAME_BASE;
        $params = getQueryParams();
        if (!$params['tmdbId'] || !$params['season'] || !$params['episode']) {
            return 'TMDB ID, season, or episode not specified.';
        }

        try {
            $details = fetchTvShowDetails($params['tmdbId']);
            $fullTitle = $details['title'] . ' (' . $details['year'] . ')';

            $filmoviplexUrl = searchFilmoviplex($fullTitle);
            if (!$filmoviplexUrl) {
                return 'Title not found.';
            }
           
    $headers = [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Referer: https://filmoviplex.com/',
        'Origin: https://filmoviplex.com'
    ];
		   
			$response = fetchDataWithCurl($filmoviplexUrl, $headers);
            if ($response === FALSE) {
                return 'Error fetching content.';
            }

            $iframeSrc = extractIframeUrl($response, $params['season'], $params['episode']);
            if ($iframeSrc) {
                $decodedUrl = decodeBase64(explode('=', $iframeSrc)[1]);
                $newUrl = replaceHost($decodedUrl, 'hqq.to');

                return '<iframe src="' . $NEW_IFRAME_BASE . '' . $newUrl . '" loading="lazy" scrolling="auto" frameborder="0" marginheight="0" marginwidth="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" width="100%" height="100%"></iframe>';
            } else {
                return 'Specified season or episode not found.';
            }
        } catch (Exception $e) {
            return 'Error fetching content: ' . $e->getMessage();
        }
    }

    echo fetchAndInsertIframe();
    ?>
</body>
</html>