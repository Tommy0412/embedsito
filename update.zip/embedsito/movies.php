<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Movies</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta name="robots" content="noindex,nofollow">
    <meta name="referrer" content="origin" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        html { 
            overflow: auto; 
            background-color: black;
        } 

        html, 
        body, 
        div, 
        iframe { 
            margin: 0; 
            padding: 0; 
            height: 100%; 
            border: none;
        } 

        iframe { 
            display: block; 
            width: 100%; 
            border: none; 
            overflow-y: auto; 
            overflow-x: hidden;
        }   

        .topleft {
            position: absolute;
            top: 8px;
            left: 16px;
            font-size: 18px;
        }

        button {
            background-color: red;
        }

        button:hover {
            background-color: red;
        }

        button:focus {
            background-color: red;
        }

        a {
            color: red;
        }

        a.button {
            color: red;
            text-decoration: none;
        }

        /* Spinner container styling */
        .iframe-container {
            position: relative;
            width: 100%;
            height: 100vh;
        }

        #loader {
            display: none;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        /* Spinner animation */
        .spinner {
            border: 4px solid #f3f3f3;
            border-radius: 50%;
            border-top: 4px solid red;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>

    <script>
        function newSrc() {
            const frame = document.getElementById('MyFrame');
            const loader = document.getElementById('loader');

            loader.style.display = 'flex';
            frame.style.display = 'none';

            const e = document.getElementById("MySelectMenu");
            const newSrcValue = e.options[e.selectedIndex].value;
            frame.src = newSrcValue;
        }

        document.addEventListener("DOMContentLoaded", function() {
            const frame = document.getElementById('MyFrame');
            const loader = document.getElementById('loader');

            let searchParams = new URLSearchParams(window.location.search);
            let id = searchParams.get("id");

            if (id) {
                const bydefault = 'rdo_ply.php?id=' + id;

                loader.style.display = 'flex';
                frame.style.display = 'none';

                frame.src = bydefault;

                frame.addEventListener('load', function() {
                    loader.style.display = 'none';
                    frame.style.display = 'block';
                });

                const selectElement = document.getElementById("MySelectMenu");
                const options = [
                    { text: "Player 1", value: 'fsonic.php?id=' + id },
                    { text: "Player 2", value: 'e_su_play.php?id=' + id },
                    { text: "Player 3", value: 'fstv.php?id=' + id },
                    { text: "Player 4", value: 'rdo_ply.php?id=' + id },
                    { text: "Player 5", value: 'src1_play.php?id=' + id },
                    { text: "Player 6", value: 'spr_play_movie.php?id=' + id },
					{ text: "Player 7 (ex-yu)", value: 'filmoviplex.php?tmdb=' + id },
					{ text: "Player 8 (ex-yu)", value: 'onlinesaprevodom.php?id=' + id },
					{ text: "Player 09 (ex-yu) 3", value: 'gledalica.php?id=' + id },
					{ text: "Player 9", value: 'zoechip_play.php?id=' + id },
					{ text: "Player 10", value: 'd00d.php?id=' + id },
					{ text: "Player 11", value: 'vidmoly.php?id=' + id },
					{ text: "Player 12", value: 'dood2.php?id=' + id },
					{ text: "Player 13", value: 'streamwish.php?id=' + id },
					{ text: "Player 14", value: 'vidhide.php?id=' + id },
					{ text: "Player 15 (German Audio)", value: 'meincloud_german_dropload.php?id=' + id },
					{ text: "Player 16 (German Audio)", value: 'meincloud_german_supervideo.php?id=' + id },
					{ text: "Player 17 (Español Latino)", value: 'verhdlink_latino_dropload.php?id=' + id },
					{ text: "Player 18 (Español Latino)", value: 'verhdlink_latino_supervideo.php?id=' + id },
					{ text: "Player 19 (Español Latino)", value: 'pelisforteplay1.php?id=' + id },
                    { text: "Backup", value: 'https://vidsrc.net/embed/movie/' + id },
                ];

                options.forEach(option => {
                    const opt = new Option(option.text, option.value);
                    selectElement.add(opt);
                });
            } else {
                loader.style.display = 'none';
                console.log("id parameter not found in URL");
            }
        });
    </script>
</head>
<body>
    <div class="flex items-center justify-center h-16">
        <select id="MySelectMenu" onchange="newSrc()" class="block w-72 p-2 bg-blue-500 border border-blue-600 rounded-lg text-white focus:outline-none focus:ring focus:ring-red-500 hover:bg-blue-600 transition duration-200">
        </select>
    </div>  
    <div class="iframe-container">
        <div id="loader">
            <div class="spinner"></div>
        </div>
        <iframe id="MyFrame" class="hidden" src="" scrolling="auto" frameborder="0" marginheight="0" marginwidth="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" width="100%" height="100%"></iframe>
    </div>
</body>
</html>