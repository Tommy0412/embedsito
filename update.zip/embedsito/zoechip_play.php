<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

function getCurrentBaseUrl() {
    $scheme = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $scriptName = dirname($_SERVER['SCRIPT_NAME']);
    $scriptName = str_replace('\\', '/', $scriptName);
    
    return $scheme . "://" . $host . $scriptName;
}

if (!isset($_GET['id'])) {
    die('ID parameter is required.');
}

$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

$baseUrl = getCurrentBaseUrl();
$apiUrl = $baseUrl . "/zoechip.php?tmdb=" . urlencode($_GET['id']);
if ($season !== null && $episode !== null) {
    $apiUrl .= "&season=" . $season . "&episode=" . $episode;
}

$response = fetchDataWithCurl($apiUrl);

if (!$response) {
    die('Failed to fetch data from the API.');
}

$data = json_decode($response, true);

if (!isset($data['netu.tv']) || empty($data['netu.tv'])) {
    die('No Netu.tv URL found.');
}

$netuUrl = $data['netu.tv'];

function fetchDataWithCurl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        error_log("HTTP error: $httpCode for URL: $url");
        return false;
    }

    return $response;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Player</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: #000;
        }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
<?php 
$baseUrl1 = getCurrentBaseUrl();
?>
    <iframe src="<?php echo $baseUrl1 ?>/netu/index.php?file=<?php echo htmlspecialchars($netuUrl); ?>" allowfullscreen></iframe>
</body>
</html>