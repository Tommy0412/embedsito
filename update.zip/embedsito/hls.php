<?php

$targetUrl = isset($_GET['url']) ? $_GET['url'] : null;
$origin = isset($_GET['origin']) ? $_GET['origin'] : null;
$referer = isset($_GET['referer']) ? $_GET['referer'] : null;

if (!$targetUrl) {
    header("HTTP/1.1 400 Bad Request");
    echo "Error: No URL specified.";
    exit;
}

function fetchWithHeaders($url, $origin, $referer) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36",
        "Origin: $origin",
        "Referer: $referer"
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        header("HTTP/1.1 $httpCode");
        echo "Error: Failed to retrieve content.";
        exit;
    }

    return $response;
}

function getCurrentBaseUrl() {
    $scheme = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $scriptName = dirname($_SERVER['SCRIPT_NAME']);
    $scriptName = str_replace('\\', '/', $scriptName);
    
    return $scheme . "://" . $host . $scriptName;
}

$playlistContent = fetchWithHeaders($targetUrl, $origin, $referer);
$baseUrl = dirname($targetUrl);
$proxiedPlaylist = preg_replace_callback('/^(?!#)(.+)$/m', function($matches) use ($baseUrl, $origin, $referer) {
    $url = trim($matches[1]);

    if (parse_url($url, PHP_URL_SCHEME) === null) {
        $url = $baseUrl . '/' . ltrim($url, '/');
    }

	$encodedUrl = urlencode($url);
    $encodedOrigin = urlencode($origin);
    $encodedReferer = urlencode($referer);
	$baseUrl1 = getCurrentBaseUrl();
    return "$baseUrl1/proxy.php?segment={$encodedUrl}&origin={$encodedOrigin}&referer={$encodedReferer}";
}, $playlistContent);

header("Content-Type: application/vnd.apple.mpegurl");
header('Content-Disposition: inline; filename="playlist.m3u8"');
echo $proxiedPlaylist;
?>