<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

$id = isset($_GET['id']) ? $_GET['id'] : null;
$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

if (!$id) {
	header('Content-Type: application/json');
    echo json_encode(['error' => 'ID is required.']);
    exit;
}

class NotFoundError extends Exception {}

function comboScraper($search, $slug, $season = null, $episode = null) {
    $normalizedSearch = preg_replace('/[^a-zA-Z0-9-_]/', '_', $search);

    $cacheFileName = $season && $episode
        ? "{$normalizedSearch}_season{$season}_episode{$episode}.json"
        : "{$normalizedSearch}.json";

    $cacheDir = __DIR__ . '/cache/';

    if (!is_dir($cacheDir)) {
        if (!mkdir($cacheDir, 0755, true)) {
            throw new Exception('Failed to create cache directory: ' . $cacheDir);
        }
    }

    $cacheFilePath = $cacheDir . $cacheFileName;

    if (file_exists($cacheFilePath)) {
        $cachedData = json_decode(file_get_contents($cacheFilePath), true);
        if ($cachedData) {
            return $cachedData;
        } else {
            //throw new Exception("Failed to decode JSON from cache file: " . $cacheFilePath);
        }
    }

    $baseUrl = 'https://catflix.su/';
    $watchPageUrl = $season && $episode
        ? "{$baseUrl}episode/$slug"
        : "{$baseUrl}movie/$slug";
    //echo $watchPageUrl;
    $watchPage = Fetcher2($watchPageUrl);

    $url = null;
	$fallbackMainOrigin = null;
    function getMainOrigin($watchPage, $fallback = null) {
    if (preg_match('/let main_origin = "(.*?)";/', $watchPage, $matches)) {
        return $matches[1];
    }
    return $fallback;
    }

    if (preg_match('/const main_origin = "(.*?)";/', $watchPage, $constMatches)) {
    $fallbackMainOrigin = $constMatches[1];
    }

    $mainOrigin = getMainOrigin($watchPage, $fallbackMainOrigin);
    $url = base64_decode($mainOrigin);

    if (!empty($url)) {
        $cachedData = ['url' => $url];
        file_put_contents($cacheFilePath, json_encode($cachedData));
        return $cachedData;
    }

    //throw new Exception('Failed to find a valid URL.');
}

function Fetcher($url, $query = []) {
    $queryString = http_build_query($query);
    $fullUrl = $url . '?' . $queryString;

    $headers = [
        'Referer: https://catflix.su/',
        'Origin: https://catflix.su',
        'X-Requested-With: XMLHttpRequest',
        'User-Agent: Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $fullUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        //throw new Exception('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);

    return $response;
}

function Fetcher2($url, $options = []) {
    $ch = curl_init();

    $queryString = isset($options['query']) ? http_build_query($options['query']) : '';
    $fullUrl = $url . ($queryString ? '?' . $queryString : '');

    curl_setopt($ch, CURLOPT_URL, $fullUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    if (isset($options['headers'])) {
        $headers = [];
        foreach ($options['headers'] as $key => $value) {
            $headers[] = "$key: $value";
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        //throw new Exception('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);

    return $response;
}

function curlRequest($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        return $response;
    }

    return null;
}

function fetchWithCurl($url, $referer) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($ch, CURLOPT_ENCODING , "");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755",
    "Origin: $referer",
    "Referer: $referer"
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL error: $error");
    }

    curl_close($ch);

    return $response;
}

function getTitleAndYear($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $isMovie = false;
    $title = '';
    $year = '';
    $episodeId = null;

    $externalUrl = $baseUrl . "find/" . $id . "?api_key=" . $apiKey . "&external_source=imdb_id";
    $externalResponse = curlRequest($externalUrl);
    if (!$externalResponse) {
        return null; 
    }
    $externalData = json_decode($externalResponse, true);

    if (isset($externalData['movie_results'][0]['id'])) {
        $tmdbId = $externalData['movie_results'][0]['id'];
        $isMovie = true;
    } elseif (isset($externalData['tv_results'][0]['id'])) {
        $tmdbId = $externalData['tv_results'][0]['id'];
    } else {
        return null;
    }

    if ($isMovie) {
        $movieUrl = $baseUrl . "movie/" . $tmdbId . "?api_key=" . $apiKey;
        $movieResponse = curlRequest($movieUrl);
        if (!$movieResponse) {
            return null;
        }
        $movieData = json_decode($movieResponse, true);

        if (isset($movieData['id'])) {
            $title = $movieData['title'];
            $year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
        }
    } else {
        $tvUrl = $baseUrl . "tv/" . $tmdbId . "?api_key=" . $apiKey;
        $tvResponse = curlRequest($tvUrl);
        if (!$tvResponse) {
            return null;
        }
        $tvData = json_decode($tvResponse, true);

        if (isset($tvData['id'])) {
            $title = $tvData['name'];
            $year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
        }

        if ($season !== null && $episode !== null) {
            $episodeUrl = $baseUrl . "tv/" . $tmdbId . "/season/" . $season . "/episode/" . $episode . "?api_key=" . $apiKey;
            $episodeResponse = curlRequest($episodeUrl);
            if (!$episodeResponse) {
                return null;
            }
            $episodeData = json_decode($episodeResponse, true);

            if (isset($episodeData['id'])) {
                $episodeId = $episodeData['id'];
            }
        }
    }

	return !empty($title) 
    ? ['title' => $title, 'year' => $year, 'episode_id' => $episodeId, 'tmdbid' => $tmdbId] 
    : null;
}

function getTitleAndYearTmdb($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $title = '';
    $year = '';
    $episodeId = null;

    if ($season !== null && $episode !== null) {
        $url = $baseUrl . "tv/" . $id . "/season/" . $season . "/episode/" . $episode . "?api_key=" . $apiKey;
        $episodeResponse = curlRequest($url);
        if (!$episodeResponse) {
            return null;
        }
        $episodeData = json_decode($episodeResponse, true);

        if (isset($episodeData['id'])) {
            $episodeId = $episodeData['id'];
        }

        $tvShowUrl = $baseUrl . "tv/" . $id . "?api_key=" . $apiKey;
        $tvShowResponse = curlRequest($tvShowUrl);
        if ($tvShowResponse) {
            $tvShowData = json_decode($tvShowResponse, true);

            $title = $tvShowData['name'] ?? '';
            $year = isset($tvShowData['first_air_date']) ? substr($tvShowData['first_air_date'], 0, 4) : '';
        }
    } else {
        $url = $baseUrl . "movie/" . $id . "?api_key=" . $apiKey;
        $movieResponse = curlRequest($url);
        if (!$movieResponse) {
            return null;
        }
        $movieData = json_decode($movieResponse, true);

        $title = $movieData['title'] ?? '';
        $year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
    }

	return !empty($title) 
    ? ['title' => $title, 'year' => $year, 'episode_id' => $episodeId, 'tmdbid' => $id] 
    : null;
}

function isImdbId($id) {
    return preg_match('/^tt\d{7,9}$/', $id);
}

function hexToChar($hex) {
    return chr(hexdec($hex));
}

function decrypt($data, $key) {
    $formatedData = '';
    if (preg_match_all('/../', $data, $matches)) {
        foreach ($matches[0] as $hex) {
            $formatedData .= hexToChar($hex);
        }
    }

    $decrypted = '';
    for ($i = 0, $len = strlen($formatedData); $i < $len; $i++) {
        $decrypted .= chr(ord($formatedData[$i]) ^ ord($key[$i % strlen($key)]));
    }

    return $decrypted;
}

function turbovidScraper($url1) {
    $baseUrl = parse_url($url1, PHP_URL_SCHEME) . '://' . parse_url($url1, PHP_URL_HOST);
    $embedPage = Fetcher2($url1, [
        'headers' => [
            'Referer' => $url1,
			'User-Agent' => 'Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755'
        ]
    ]);

    preg_match('/const\s+apkey\s*=\s*"(.*?)";/', $embedPage, $apkeyMatches);
    preg_match('/const\s+xxid\s*=\s*"(.*?)";/', $embedPage, $xxidMatches);

    $apkey = $apkeyMatches[1] ?? null;
    $xxid = $xxidMatches[1] ?? null;

    if (!$apkey || !$xxid) {
        throw new Exception('Failed to get required values');
    }

$juiceKeyResponse = Fetcher2($baseUrl . '/api/cucked/juice_key', [
    'headers' => [
        'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
        'Accept' => '*/*',
        'Accept-Language' => 'en-US,en;q=0.9',
        'Connection' => 'keep-alive',
        'Content-Type' => 'application/json',
        'X-Turbo' => 'TurboVidClient',
        'Sec-Fetch-Dest' => 'empty',
        'Sec-Fetch-Mode' => 'cors',
        'Sec-Fetch-Site' => 'same-origin',
        'Referer' => $url1,
    ]
]);
//print_r($juiceKeyResponse);
    $juiceKey1 = json_decode($juiceKeyResponse, true)['juice'] ?? null;
	$juiceKey = base64_decode($juiceKey1);
	//echo $juiceKey;

    if (!$juiceKey) {
        throw new Exception('Failed to fetch the key');
    }

    $dataResponse = Fetcher2($baseUrl . '/api/cucked/the_juice/', [
        'query' => [
            $apkey => $xxid
        ],
    'headers' => [
        'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
        'Accept' => '*/*',
        'Accept-Language' => 'en-US,en;q=0.9',
        'Connection' => 'keep-alive',
        'Content-Type' => 'application/json',
        'X-Turbo' => 'TurboVidClient',
        'Sec-Fetch-Dest' => 'empty',
        'Sec-Fetch-Mode' => 'cors',
        'Sec-Fetch-Site' => 'same-origin',
        'Referer' => $url1,
    ]
    ]);
    $data = json_decode($dataResponse, true)['data'] ?? null;

    if (!$data) {
        throw new Exception('Failed to fetch required data');
    }

    $playlist1 = decrypt($data, $juiceKey);
    $headers = 'User-Agent="Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755"|Referer=https://turbovid.eu/|Origin=https://turbovid.eu';
	$encoded_headers = base64_encode($headers);
	$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $Playlist = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/poxy.php?url=' . $playlist1 . '&data=' . $encoded_headers;
	return [
            'direct_link' => $Playlist,
        ];
}

function getMovieSlug($search, $id) {
    return makeUrlFriendly($search) . "-" . $id;
}

function makeUrlFriendly($search) {
    if (!is_string($search)) {
        $search = ''; 
    }

    $search = preg_replace(
        [
            '/[^a-z0-9\\x{0400}-\\x{04FF}\\s-]/iu', 
            '/[\\s-]+/'                             
        ],
        ['','-'],
        trim($search)
    );

    return strtolower($search);
}

if (isImdbId($id)) {
$call = getTitleAndYear($id, $season, $episode);
} else {
$call = getTitleAndYearTmdb($id, $season, $episode);
}

if ($call) {
$search = $call['title'];
$godina = $call['year'];
$episode_id = $call['episode_id'];
$tmdbid = $call['tmdbid'];
}

try {
	if ($season !== null && $episode !== null) {
	$slug1 = makeUrlFriendly($search);	
	$slug = "$slug1-season-$season-episode-$episode/eid-$episode_id";
	$result = comboScraper($search,$slug,$season,$episode);
	$url = $result['url'];
	} else {
    $slug = getMovieSlug($search,$tmdbid);	
	$result = comboScraper($search,$slug);
	$url = $result['url'];
	}
    if (!empty($url)) {
        $turbovid = turbovidScraper($url);
        header('Content-Type: application/json');
        $jsonResult = json_encode($turbovid, JSON_PRETTY_PRINT);
        echo $jsonResult;
    } else {
        throw new Exception("URL is not set or empty.");
    }
	exit;
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}