<?php 
$segmentUrl = isset($_GET['segment']) ? $_GET['segment'] : null;
$origin = isset($_GET['origin']) ? $_GET['origin'] : null;
$referer = isset($_GET['referer']) ? $_GET['referer'] : null;

if (!$segmentUrl) {
    header("HTTP/1.1 400 Bad Request");
    //echo "Error: No segment URL specified.";
    exit;
}

function fetchSegmentWithHeaders($url, $origin, $referer) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $headers = [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36",
        "Origin: $origin",
        "Referer: $referer"
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    
    if ($response === false) {
        $error = curl_error($ch);
        curl_close($ch);
        header("HTTP/1.1 502 Bad Gateway");
        //echo "Error: Failed to retrieve segment content. cURL Error: $error";
        exit;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        header("HTTP/1.1 $httpCode");
        //echo "Error: Failed to retrieve segment content. HTTP Code: $httpCode";
        exit;
    }

    return $response;
}

$segmentContent = fetchSegmentWithHeaders($segmentUrl, $origin, $referer);

header("Content-Type: video/MP2T");
header("Cache-Control: no-store"); 
header("Content-Length: " . strlen($segmentContent));
header('Content-Disposition: inline; filename="segment.ts"');
echo $segmentContent;
?>