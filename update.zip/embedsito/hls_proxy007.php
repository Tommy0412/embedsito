<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1); 

set_time_limit(0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Authorization, Accept");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$userSetHost = '';
$proxyUrl = locateBaseURL() . "hls_proxy007.php";

function locateBaseURL() {
    global $userSetHost;

    $protocol = 'http://';

    if (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
        (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') ||
        (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
    ) {
        $protocol = 'https://';
    }

    $domain = isset($userSetHost) && !empty($userSetHost) ? $protocol . $userSetHost : $protocol . $_SERVER['HTTP_HOST'];

    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    $scriptDir = ($scriptDir === '/' || $scriptDir === '\\') ? '' : trim($scriptDir, '/\\');

    $baseUrl = rtrim($domain, '/') . '/' . $scriptDir;
    $baseUrl = rtrim($baseUrl, '/') . '/';

    return $baseUrl;
}

function fetchContent($url, $additionalHeaders = [], $isMaster) {
    $decodedData = base64_decode($_GET['data']);
    $parts = explode('|', $decodedData);
    $maxRedirects = 2;
    $headers = [];
    $origin = '';

    if (!$isMaster) {
        $parsedUrl = parse_url($url);
        $origin = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
    }

    foreach ($parts as $headerData) {
        if (strpos($headerData, '=') !== false) {
            list($header, $value) = explode('=', $headerData, 2);
            $header = trim($header);
            $value = trim($value, "'\"");
            if (!$isMaster && ($header === 'Origin')) {
                continue;
            }
            $headers[] = $header . ": " . $value;
        }
    }

    //if (!$isMaster) {
        //$headers[] = 'Origin: ' . $origin;
    //}

    if (isset($_SERVER['HTTP_RANGE'])) {
        $headers[] = "Range: " . $_SERVER['HTTP_RANGE'];
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_MAXREDIRS, $maxRedirects);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

    $redirectCount = 0;
    $response = '';
    $finalUrl = $url;
    $contentType = '';
    $statusCode = 0;

    do {
        curl_setopt($ch, CURLOPT_URL, $finalUrl);
        $response = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);

        if (in_array($statusCode, [301, 302, 303, 307, 308])) {
            $redirectCount++;
            $finalUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        } else {
            break;
        }
    } while ($redirectCount < $maxRedirects);

    curl_close($ch);

    return [
        'content' => $response,
        'finalUrl' => $finalUrl,
        'statusCode' => $statusCode,
        'contentType' => $contentType
    ];
}

function isMasterRequest($queryParams) {
    return isset($queryParams['url']) && !isset($queryParams['url2']);
}

function rewriteUrls($content, $originalPlaylistUrl, $proxyUrl, $data) {
    $lines = explode("\n", $content);
    $rewrittenLines = [];
    $isNextLineUri = false;

    $parsedOriginalUrl = parse_url($originalPlaylistUrl);

    $rootUrl = $parsedOriginalUrl['scheme'] . '://' . $parsedOriginalUrl['host'];
    if (isset($parsedOriginalUrl['port'])) {
        $rootUrl .= ':' . $parsedOriginalUrl['port'];
    }

    $fullBaseUrl = $parsedOriginalUrl['scheme'] . '://' . $parsedOriginalUrl['host'] . $parsedOriginalUrl['path'];

    foreach ($lines as $line) {
        if (empty(trim($line)) || $line[0] === '#') {
            if (preg_match('/URI="([^"]+)"/i', $line, $matches)) {
                $uri = $matches[1];

                if (strpos($uri, 'http') !== 0) {
                    $uriBase = (strpos($uri, '/') === 0 || strpos($uri, '../') === 0) ? $rootUrl : $fullBaseUrl;
                    $uri = rtrim($uriBase, '/') . '/' . ltrim($uri, '/');
                }

                if (strpos($uri, 'hls_proxy007.php') === false) {
                    $rewrittenUri = $proxyUrl . '?url=' . urlencode($uri) . '&data=' . urlencode($data);
                    if (strpos($line, '#EXT-X-KEY') !== false) {
                        $rewrittenUri .= '&key=true';
                    }
                    $line = preg_replace('/URI="[^"]+"/i', 'URI="' . $rewrittenUri . '"', $line);
                }
            }
            $rewrittenLines[] = $line;

            if (strpos($line, '#EXT-X-STREAM-INF') !== false) {
                $isNextLineUri = true;
            }
            continue;
        }

        $urlParam = $isNextLineUri ? 'url' : 'url2';

        if (!filter_var($line, FILTER_VALIDATE_URL)) {
            $lineBase = (strpos($line, '/') === 0 || strpos($line, '../') === 0) ? $rootUrl : $fullBaseUrl;
            $line = rtrim($lineBase, '/') . '/' . ltrim($line, '/');
        }

        if (strpos($line, 'hls_proxy007.php') === false) {
            $fullUrl = $proxyUrl . "?$urlParam=" . urlencode($line) . '&data=' . urlencode($data) . (($urlParam === 'url') ? '&type=/index.m3u8' : '&type=/index.ts');
            $rewrittenLines[] = $fullUrl;
        } else {
            $rewrittenLines[] = $line;
        }

        $isNextLineUri = false;
    }
    return implode("\n", $rewrittenLines);
}

function handleProxiedUrl() {
    if (isset($_GET['url'])) {
        $decodedUrl = urldecode($_GET['url']);

        if (strpos($decodedUrl, '=https://') !== false || strpos($decodedUrl, '=http://') !== false) {
            $data = $_GET['data'] ?? '';
            if (!empty($data)) {
                $decodedData = base64_decode($data);
                $headers = explode('|', $decodedData);

                foreach ($headers as $header) {
                    if (!empty($header)) {
                        list($headerName, $headerValue) = explode('=', $header, 2);
                        if (!empty($headerName) && !empty($headerValue)) {
                            header("$headerName: $headerValue");
                        }
                    }
                }
            }

            header("Location: $decodedUrl");
            exit;
        }
    }
}

handleProxiedUrl();

$isMaster = isMasterRequest($_GET);
$data = $_GET['data'] ?? '';
$requestUrl = $isMaster ? ($_GET['url'] ?? '') : ($_GET['url2'] ?? '');

$result = fetchContent($requestUrl, $data, $isMaster);

if ($result['content'] === '') {
    http_response_code('404');
    echo '404 / Not Found!';
    echo $result['content'];
    exit;
}

if ($result['statusCode'] >= 400) {
    http_response_code($result['statusCode']);
    switch ($result['statusCode']) {
        case 400:
            echo 'Bad Request!';
            break;
        case 401:
            echo 'Unauthorized!';
            break;
        case 403:
            echo 'Forbidden!';
            break;
        case 404:
            echo 'Not Found!';
            break;
        default:
            echo 'An error occurred! Status code: ' . $result['statusCode'];
            break;
    }
    exit;
}

$content = $result['content'];
$finalUrl = $result['finalUrl'];
$baseUrl = dirname($finalUrl);

$statusCode = $result['statusCode'];
$contentType = $result['contentType'];

if ($isMaster) {
    $content = rewriteUrls($content, $baseUrl, $proxyUrl, $data);
} 

// Set proper headers based on content type
if (isset($_GET['type'])) {
    $type = $_GET['type'];
    if ($type === '/index.m3u8') {
        header('Content-Type: application/x-mpegURL');
        header('Content-Disposition: attachment; filename="playlist.m3u8"');
    } elseif ($type === '/index.ts') {
        header('Content-Type: video/mp2t');
        header('Content-Disposition: attachment; filename="segment.ts"');
    }
} elseif ($isMaster) {
    header('Content-Type: application/x-mpegURL');
    header('Content-Disposition: attachment; filename="playlist.m3u8"');
} else {
    header('Content-Type: video/mp2t');
    header('Content-Disposition: attachment; filename="segment.ts"');
}

http_response_code($statusCode);
echo $content;
?>