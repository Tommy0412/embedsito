<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

function getCurrentBaseUrl() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    return "$scheme://$host$path/";
}

function scrapeVerdahd($imdbid) {
    $baseurl = "https://play.verhdlink.cam";
    $finalstreams = [];
    $url = "$baseurl/movie/$imdbid";
    
    $html = curlGetContents($url);
    if (!$html) {
        return null;
    }
    
    preg_match_all('/<ul class="_player-mirrors\s+[^"]+\s+top_class [\s\S]*?<\/ul>/', $html, $matches);

    foreach ($matches[0] as $content) {
        $lang = "";
        if (strpos($content, "latino") !== false) {
            $lang = "Latino";
        } elseif (strpos($content, "subtitulado") !== false) {
            $lang = "Subtitled";
        } elseif (strpos($content, "castellano") !== false) {
            $lang = "Castellano";
        }
        
        preg_match_all('/dropload\.io\/([^"]+)/', $content, $streamtapeMatches);
        foreach ($streamtapeMatches[0] as $match) {
			$embedurl = "https://$match";
            $initialurl = droploadResolve($embedurl);
			$baseUrl = getCurrentBaseUrl();
			$urlData = "|Origin=https://dropload.io|Referer=https://dropload.io/|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";
            if ($embedurl) {
			$hlsStream = $baseUrl . 'hls_proxy.php?url=' . urlencode($initialurl) . '&data=' . base64_encode($urlData);
			}	
			$finalstreams[] = [
                "url" => $hlsStream,
                "title" => "$lang - (dropload.io)"
            ];
        }
        
        preg_match_all('/supervideo\.cc\/([^"]+)/', $content, $supervideoMatches);
        foreach ($supervideoMatches[0] as $match) {
            $embedurl = "https://$match";
            $url = getMediaUrl($embedurl);
            $finalstreams[] = [
                "url" => $url,
                "title" => "$lang - (supervideo.cc)"
            ];
        }
    }
    
    return $finalstreams;
}

function getImdbIdFromTmdb($tmdbId) {
    $apiKey = "1428c4185bce6abd6564049d1351970d";
    $url = "https://api.themoviedb.org/3/movie/{$tmdbId}/external_ids?api_key={$apiKey}";

    $response = httpGet($url);
    if (!$response) {
        return null;
    }

    $data = json_decode($response, true);

    if (isset($data['imdb_id']) && !empty($data['imdb_id'])) {
        return $data['imdb_id']; 
    }

    return null;
}

function curlGetContents($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
        "Origin: https://verhdlink.cam",
        "Referer: https://verhdlink.cam/"
    ]);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

function droploadResolve($host) {
    $headers = [
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer' => $host
    ];

    $html = httpGet($host, $headers);
    $packed_data = getPackedData($html);
	 
    if ($packed_data) {
        $pattern = '/sources:\s*\[\s*\{[^}]*file:\s*"([^"]+)"/';
        if (preg_match($pattern, $packed_data, $matches)) {
            return $matches[1];
        }
    }		

    return null;
}

function httpGet($url, $headers = []) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

function getPackedData($html) {
    require_once("JavaScriptUnpacker.php");
    $jsu = new JavaScriptUnpacker();
    $packed_data = '';
    $pattern = '/(eval\s*\(function\(p,a,c,k,e,.*?)<\/script>/is';

    if (preg_match_all($pattern, $html, $matches)) {
        foreach ($matches[1] as $r) {
            if (preg_match('/eval\s*\(function\(p,a,c,k,e,/i', $r)) {
                $packed_data .= $jsu->Unpack($r);
            } else {
                $t = preg_split('/eval/i', $r, -1, PREG_SPLIT_NO_EMPTY);
                foreach ($t as $part) {
                    $part = 'eval' . $part;
                    $packed_data .= $jsu->Unpack($part);
                }
            }
        }
    }
    return $packed_data;
}

function getMediaUrl($host) {
    $headers = [
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer' => $host
    ];

    $html = httpGet($host, $headers);

    $packed_data = getPackedData($html);
    if ($packed_data) {
        $pattern = '/sources:\s*\[\s*\{[^}]*file:\s*"([^"]+)"/';
        if (preg_match($pattern, $packed_data, $matches)) {
            return $matches[1];
        }
    }

    return null;
}

$id = isset($_GET['id']) ? $_GET['id'] : null;

$imdbId = getImdbIdFromTmdb($id);

$streams = scrapeVerdahd($imdbId);
header('Content-Type: application/json');

$jsonOutput = json_encode($streams, JSON_PRETTY_PRINT);

echo $jsonOutput;
exit();
?>