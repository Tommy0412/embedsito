<?php
error_reporting(0);
set_time_limit(0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Authorization, Accept");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$userSetHost = '';
$proxyUrl = locateBaseURL() . "hls_proxy0.php";

function locateBaseURL() {
    global $userSetHost;

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

    $domain = isset($userSetHost) && !empty($userSetHost) ? $protocol . $userSetHost : $protocol . $_SERVER['HTTP_HOST'];

    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    $scriptDir = ($scriptDir === '/' || $scriptDir === '\\') ? '' : trim($scriptDir, '/\\');

    $baseUrl = rtrim($domain, '/') . '/' . $scriptDir;
    $baseUrl = rtrim($baseUrl, '/') . '/'; 

    return $baseUrl;
}

function fetchContent($url, $additionalHeaders = [], $isMaster) {
    $decodedData = base64_decode($_GET['data']);
    $parts = explode('|', $decodedData);
    $maxRedirects = 2;
    $headers = [];
    $origin = '';

    if (!$isMaster) {
        $parsedUrl = parse_url($url);
        $origin = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];       
    }
    
    foreach ($parts as $headerData) {
        if (strpos($headerData, '=') !== false) {
            list($header, $value) = explode('=', $headerData, 2);
            $header = trim($header);
            $value = trim($value, "'\"");            
            if (!$isMaster && ($header === 'Origin')) {
                continue; 
            }
            $headers[] = $header . ": " . $value;
        }
    }

    if (!$isMaster) {
        $headers[] = 'Origin: ' . $origin;
    }

    if (isset($_SERVER['HTTP_RANGE'])) {
        $headers[] = "Range: " . $_SERVER['HTTP_RANGE'];
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_MAXREDIRS, $maxRedirects);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    
    $redirectCount = 0;
    $response = '';
    $finalUrl = $url;
    $contentType = '';
    $statusCode = 0;

    do {
        curl_setopt($ch, CURLOPT_URL, $finalUrl);
        $response = curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);

        if (in_array($statusCode, [301, 302, 303, 307, 308])) {
            $redirectCount++;
            $finalUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        } else {
            break;
        }
    } while ($redirectCount < $maxRedirects);

    curl_close($ch);
    if (connection_aborted()) {
        exit;
    }

    return [
        'content' => $response,
        'finalUrl' => $finalUrl,
        'statusCode' => $statusCode,
        'contentType' => $contentType
    ];
}

function isMasterRequest($queryParams) {
    return isset($queryParams['url']) && !isset($queryParams['url2']);
}

function rewriteUrls($content, $originalPlaylistUrl, $proxyUrl, $data) {
    $lines = explode("\n", $content);
    $rewrittenLines = [];
    $isNextLineUri = false;

    $parsedOriginalUrl = parse_url($originalPlaylistUrl);
    $rootUrl = $parsedOriginalUrl['scheme'] . '://' . $parsedOriginalUrl['host'];
    if (isset($parsedOriginalUrl['port'])) {
        $rootUrl .= ':' . $parsedOriginalUrl['port'];
    }
    $path = dirname($parsedOriginalUrl['path']);
    $fullBaseUrl = $rootUrl . $path;

    foreach ($lines as $line) {
        if (empty(trim($line)) || $line[0] === '#') {
            if (preg_match('/URI="([^"]+)"/i', $line, $matches)) {
                $uri = $matches[1];
               
                // Handle protocol-relative and relative URIs
                if (strpos($uri, 'http') !== 0) {
                    if (strpos($uri, '//') === 0) {
                        $uri = $parsedOriginalUrl['scheme'] . ':' . $uri;
                    } else {
                        $uriBase = (strpos($uri, '/') === 0) ? $rootUrl : $fullBaseUrl;
                        $uri = rtrim($uriBase, '/') . '/' . ltrim($uri, '/');
                    }
                }

                if (strpos($uri, 'hls_proxy0.php') === false) {
                    $rewrittenUri = $proxyUrl . '?url=' . urlencode($uri) . '&data=' . urlencode($data);
                    if (strpos($line, '#EXT-X-KEY') !== false) {
                        $rewrittenUri .= '&key=true';
                    }
                    $line = preg_replace('/URI="[^"]+"/i', 'URI="' . $rewrittenUri . '"', $line);
                }
            }
            $rewrittenLines[] = $line;

            if (strpos($line, '#EXT-X-STREAM-INF') !== false) {
                $isNextLineUri = true;
            }
            continue;
        }

        $urlParam = $isNextLineUri ? 'url' : 'url2';

        if (!filter_var($line, FILTER_VALIDATE_URL)) {
            if (strpos($line, '//') === 0) {
                $line = $parsedOriginalUrl['scheme'] . ':' . $line;
            } else {
                $lineBase = (strpos($line, '/') === 0) ? $rootUrl : $fullBaseUrl;
                $line = rtrim($lineBase, '/') . '/' . ltrim($line, '/');
            }
        }

        if (strpos($line, 'hls_proxy0.php') === false) {
            $fullUrl = $proxyUrl . "?$urlParam=" . urlencode($line) . '&data=' . urlencode($data) . (($urlParam === 'url') ? '&type=/index.m3u8' : '&type=/index.ts');
            $rewrittenLines[] = $fullUrl;
        } else {
            $rewrittenLines[] = $line;
        }

        $isNextLineUri = false;
    }
    return implode("\n", $rewrittenLines);
}

function fetchEncryptionKey($url, $data) {
    if (isset($_GET['key']) && $_GET['key'] === 'true') {
        
        // Handler for daddylive
        if (strpos($url, 'premium') !== false && strpos($url, 'number') !== false) {
            $url = str_replace('key2.', 'key.', $url);
        }
        $decodedData = base64_decode($data);
        $parts = explode('|', $decodedData);
        $maxRedirects = 5;
        $headers = [];

        foreach ($parts as $headerData) {
            if (strpos($headerData, '=') !== false) {
                list($header, $value) = explode('=', $headerData, 2);
                $headers[] = trim($header) . ": " . trim($value, "'\"");
            }
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, $maxRedirects);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

        $response = curl_exec($ch);
        curl_close($ch);

        $etag = '"' . md5($response) . '"';
        if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH']) == $etag) {
            header("HTTP/1.1 304 Not Modified");
            exit;
        }

        header('Content-Type: application/octet-stream');
        header('Cache-Control: max-age=3600');
        header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT');
        header('ETag: ' . $etag);

        echo $response;
        exit;
    }
}

// Check if the URL is already proxied and just redirect
function handleProxiedUrl() {
    if (isset($_GET['url'])) {
        $decodedUrl = urldecode($_GET['url']);        
       
        if (strpos($decodedUrl, '=https://') !== false || strpos($decodedUrl, '=http://') !== false) {
            $data = $_GET['data'] ?? '';
            if (!empty($data)) {
                $decodedData = base64_decode($data);
                $headers = explode('|', $decodedData);

                foreach ($headers as $header) {
                    if (!empty($header)) {
                        list($headerName, $headerValue) = explode('=', $header, 2);
                        if (!empty($headerName) && !empty($headerValue)) {
                            header("$headerName: $headerValue");
                        }
                    }
                }
            }

            header("Location: $decodedUrl");
            exit;
        }
    }
}

handleProxiedUrl();

// Main processing logic
$isMaster = isMasterRequest($_GET);
$data = $_GET['data'] ?? '';
$requestUrl = $isMaster ? ($_GET['url'] ?? '') : ($_GET['url2'] ?? '');
fetchEncryptionKey($requestUrl, $_GET['data']);
$result = fetchContent($requestUrl, $data, $isMaster);

if ($result['content'] === '') {
    http_response_code('404');
    echo '404 / Not Found!';
    echo $result['content'];
    exit;
}    

if ($result['statusCode'] >= 400) {
    http_response_code($result['statusCode']);
    switch ($result['statusCode']) {
        case 400:
            echo 'Bad Request!';
            break;
        case 401:
            echo 'Unauthorized!';
            break;
        case 403:
            echo 'Forbidden!';
            break;
        case 404:
            echo 'Not Found!';
            break;
        default:
            echo 'An error occurred! Status code: ' . $result['statusCode'];
            break;
    }
    exit;
}

$content = $result['content'];
$finalUrl = $result['finalUrl'];
$baseUrl = dirname($finalUrl);

$statusCode = $result['statusCode'];
$contentType = $result['contentType'];

if ($isMaster) {
    $content = rewriteUrls($content, $finalUrl, $proxyUrl, $data);
} 

if (isset($contentType) && (stripos($contentType, 'mpeg') !== false || stripos($contentType, 'video') !== false)) {
    header('Content-Type: ' . $contentType);
} else {   
    header('Content-Type: application/x-mpegURL');
}

http_response_code($statusCode);
echo $content;
?>