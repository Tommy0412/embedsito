<?php

function getProtocol() {
    $protocol = "http://";

    if (!empty($_SERVER['HTTP_CF_VISITOR'])) {
        $cfVisitor = json_decode($_SERVER['HTTP_CF_VISITOR'], true);
        if (!empty($cfVisitor['scheme'])) {
            return $cfVisitor['scheme'] . "://";
        }
    }

    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
        $proto = strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']);
        if ($proto === 'https') {
            return "https://";
        }
    }

    if (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
    ) {
        $protocol = "https://";
    }

    return $protocol;
}

function getMovieStream($subjectId, $detailPath, $season = 0, $episode = 0) {
    //$IP = "102.89.23.15";
    $IP = "127.0.0.1";

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_URL => "https://moviebox.ph/wefeed-h5-bff/web/subject/play?subjectId={$subjectId}&se={$season}&ep={$episode}",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => false,
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'accept-language: en-GB,en;q=0.9',
            'priority: u=1, i',
            'sec-ch-ua: "Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-fetch-dest: empty',
            'sec-fetch-mode: cors',
            'sec-fetch-site: same-origin',
            'x-client-info: {"timezone":"Africa/Lagos"}',
            'x-source: ',
            "Referer: https://moviebox.ph/movies/{$detailPath}?id={$subjectId}&scene=&page_from=suggestion&type=/movie/detail&utm_source=",
            'Referrer-Policy: strict-origin-when-cross-origin',
            "X-Forwarded-For: $IP",
            "CF-Connecting-IP: $IP",
            "True-Client-IP: $IP"
        ],
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        return null;
    }

    curl_close($ch);

    $data = json_decode($response, true);

    if (!$data || !isset($data['data']['streams'])) {
        return null;
    }

    $protocol = getProtocol();
    $domain = $_SERVER['HTTP_HOST'];
    $path = dirname($_SERVER['PHP_SELF']);
    $path = str_replace('\\', '/', $path);

    if ($path === '/' || $path === '\\') {
        $path = '';
    }

    $currentUrl = rtrim($protocol . $domain . $path, '/');

    $streams = [];
    $firstId = null;

    foreach ($data['data']['streams'] as $stream) {
        $url = $stream['url'];
        $streamId = $stream['id'];

        if ($firstId === null) {
            $firstId = $streamId; 
        }

        $urlData = "{$url}"
            . "|Referer=https://fmoviesunblocked.net/"
            . "|Origin=https://moviebox.ph"
            . "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
            . "|accept-language=en-GB,en-US;q=0.9,en;q=0.8"
            . "|priority=u=1, i"
            . "|sec-ch-ua=\"Chromium\";v=\"136\", \"Google Chrome\";v=\"136\", \"Not.A/Brand\";v=\"99\""
            . "|sec-ch-ua-mobile=?0"
            . "|sec-ch-ua-platform=\"Windows\""
            . "|sec-fetch-dest=empty"
            . "|sec-fetch-mode=cors"
            . "|sec-fetch-site=same-origin"
            . "|x-client-info={\"timezone\":\"Africa/Lagos\"}"
            . "|cookie=i18n_lang=en; _ga=GA1.1.1233380562.1748892912; account=3178832500353289608|0|H5|1748911805|; _ga_LF2XQTEPMF=GS2.1.s1748924351$o4$g1$t1748925105$j59$l0$h0"
            . "|X-Forwarded-For={$IP}"
            . "|CF-Connecting-IP={$IP}"
            . "|True-Client-IP={$IP}"
            . "|Referrer-Policy=strict-origin-when-cross-origin";

        $encoded_headers = base64_encode($urlData);
        $proxyUrl = "{$currentUrl}/video_proxy1.php?data={$encoded_headers}";

        $res = $stream['resolutions'] ?? 'unknown';

        $streams[$res] = [
            'id'  => $streamId,
            'url' => $proxyUrl
        ];
    }

    $captions = null;
if ($firstId) {
    $rawCaptions = fetchMovieCaptions($firstId, $subjectId);

    if ($rawCaptions && isset($rawCaptions['data']['captions'])) {
        $captions = array_map(function ($c) {
            return [
                'lan' => $c['lan'],
                'url' => $c['url']
            ];
        }, $rawCaptions['data']['captions']);
    }
}

    return [
        'streams'  => $streams,
        'captions' => $captions
    ];
}

function searchMovie($title) {
    $ch = curl_init();

    $postData = json_encode([
        'keyword' => $title,
        'page' => 1,
        'perPage' => 0,
        'subjectType' => 0
    ]);

    curl_setopt_array($ch, [
        CURLOPT_URL => 'http://moviebox.ph/wefeed-h5-bff/web/subject/search',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'accept-language: en-GB,en-US;q=0.9,en;q=0.8',
            'content-type: application/json',
            'x-client-info: {"timezone":"Africa/Lagos"}',
            'cookie: i18n_lang=en; _ga=GA1.1.1233380562.1748892912; _ga_LF2XQTEPMF=GS2.1.s1748892912$o1$g1$t1748892975$j60$l0$h0',
            'Referer: http://moviebox.ph/web/searchResult?keyword=' . urlencode($title) . '&utm_source=',
            'Referrer-Policy: strict-origin-when-cross-origin'
        ],
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        CURLOPT_SSL_VERIFYPEER => false
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        return null;
    }

    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['data']['items'])) {
        foreach ($data['data']['items'] as $item) {
            if (
                isset($item['title'], $item['subjectType']) &&
                strcasecmp($item['title'], $title) === 0 && 
                $item['subjectType'] == 1
            ) {
                return [
                    'subjectId' => $item['subjectId'],
                    'detailPath' => $item['detailPath']
                ];
            }
        }
    }

    return null;
}

function searchTv1($title) {
    $ch = curl_init();

    $postData = json_encode([
        'keyword' => $title,
        'page' => 1,
        'perPage' => 0,
        'subjectType' => 0
    ]);

    curl_setopt_array($ch, [
        CURLOPT_URL => 'http://moviebox.ph/wefeed-h5-bff/web/subject/search',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'accept-language: en-GB,en-US;q=0.9,en;q=0.8',
            'content-type: application/json',
            'x-client-info: {"timezone":"Africa/Lagos"}',
            'cookie: i18n_lang=en; _ga=GA1.1.1233380562.1748892912; _ga_LF2XQTEPMF=GS2.1.s1748892912$o1$g1$t1748892975$j60$l0$h0',
            'Referer: http://moviebox.ph/web/searchResult?keyword=' . urlencode($title) . '&utm_source=',
            'Referrer-Policy: strict-origin-when-cross-origin'
        ],
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        CURLOPT_SSL_VERIFYPEER => false
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        return null;
    }

    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['data']['items'])) {
        foreach ($data['data']['items'] as $item) {
            if (
                isset($item['title'], $item['subjectType']) &&
                strcasecmp($item['title'], $title) === 0 && 
                $item['subjectType'] == 2
            ) {
                return [
                    'subjectId' => $item['subjectId'],
                    'detailPath' => $item['detailPath']
                ];
            }
        }
    }

    return null;
}

function searchTv($title) {
    $ch = curl_init();

    $postData = json_encode([
        'keyword' => $title,
        'page' => 1,
        'perPage' => 0,
        'subjectType' => 0
    ]);

    curl_setopt_array($ch, [
        CURLOPT_URL => 'http://moviebox.ph/wefeed-h5-bff/web/subject/search',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'accept-language: en-GB,en-US;q=0.9,en;q=0.8',
            'content-type: application/json',
            'x-client-info: {"timezone":"Africa/Lagos"}',
            'cookie: i18n_lang=en; _ga=GA1.1.1233380562.1748892912; _ga_LF2XQTEPMF=GS2.1.s1748892912$o1$g1$t1748892975$j60$l0$h0',
            'Referer: http://moviebox.ph/web/searchResult?keyword=' . urlencode($title) . '&utm_source=',
            'Referrer-Policy: strict-origin-when-cross-origin'
        ],
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        CURLOPT_SSL_VERIFYPEER => false
    ]);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        curl_close($ch);
        return null;
    }

    curl_close($ch);

    $data = json_decode($response, true);

    $fallback = null; 

    if (isset($data['data']['items'])) {
        foreach ($data['data']['items'] as $item) {
            if (isset($item['title'], $item['subjectType']) && strcasecmp($item['title'], $title) === 0) {
                if ($item['subjectType'] == 2) {
                    // exact TV match
                    return [
                        'subjectId' => $item['subjectId'],
                        'detailPath' => $item['detailPath']
                    ];
                } elseif ($item['subjectType'] == 1006 && !$fallback) {
                    // store first 1006 as fallback
                    $fallback = [
                        'subjectId' => $item['subjectId'],
                        'detailPath' => $item['detailPath']
                    ];
                }
            }
        }
    }

    return $fallback;
}

function fetchMovieCaptions($id, $subjectId) {
	$IP = "127.0.0.1";
    $url = "https://moviebox.ph/wefeed-h5-bff/web/subject/caption?format=MP4&id=" . urlencode($id) . "&subjectId=" . urlencode($subjectId);
    
    $ch = curl_init();
    
    $headers = [
        'accept: application/json',
        'accept-language: en-GB,en-US;q=0.9,en;q=0.8',
        'priority: u=1, i',
        'sec-ch-ua: "Chromium";v="136", "Google Chrome";v="136", "Not.A/Brand";v="99"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'sec-fetch-dest: empty',
        'sec-fetch-mode: cors',
        'sec-fetch-site: same-origin',
        'x-client-info: {"timezone":"Africa/Lagos"}',
        'cookie: i18n_lang=en; _ga=GA1.1.1233380562.1748892912; account=3178832500353289608|0|H5|1748911805|; _ga_LF2XQTEPMF=GS2.1.s1748924351$o4$g1$t1748925105$j59$l0$h0',
        'Referer: https://moviebox.ph/',
		'Referrer-Policy: strict-origin-when-cross-origin',
        "X-Forwarded-For: $IP",
        "CF-Connecting-IP: $IP",
        "True-Client-IP: $IP"
    ];
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_HEADER => false,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
        CURLOPT_REFERER => 'https://moviebox.ph/',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_error($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['error' => 'cURL Error: ' . $error];
    }
    
    curl_close($ch);
    
    if ($httpCode !== 200) {
        //return ['error' => 'HTTP Error: ' . $httpCode, 'response' => $response];
    }
    //header('Content-Type: application/json');
    $jsonResponse = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['error' => 'Invalid JSON response', 'raw_response' => $response];
    }
    
    return $jsonResponse;
}

$id = isset($_GET['id']) ? $_GET['id'] : null;
$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

if (!$id) {
	header('Content-Type: application/json');
    echo json_encode(['error' => 'ID is required.']);
    exit;
}

function getTitleAndYear($id, $season = null, $episode = null) {
    $apiKey  = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $lang    = 'en-EN';
    
    $isMovie = false;
    $title   = '';
    $year    = '';

    $externalUrl = $baseUrl . "find/{$id}?api_key={$apiKey}&external_source=imdb_id&language={$lang}";
    $externalResponse = @file_get_contents($externalUrl);
    if ($externalResponse === false) {
        return null;
    }

    $externalData = json_decode($externalResponse, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return null;
    }

    if (isset($externalData['movie_results'][0]['id'])) {
        $tmdbId  = $externalData['movie_results'][0]['id'];
        $isMovie = true;
    } elseif (isset($externalData['tv_results'][0]['id'])) {
        $tmdbId = $externalData['tv_results'][0]['id'];
    } else {
        return null;
    }

    if ($isMovie) {
        $movieUrl = $baseUrl . "movie/{$tmdbId}?api_key={$apiKey}&language={$lang}";
        $movieResponse = @file_get_contents($movieUrl);
        if ($movieResponse === false) {
            return null;
        }

        $movieData = json_decode($movieResponse, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        if (isset($movieData['id'])) {
            $title = $movieData['title'] ?? '';
            $year  = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
        }
    } else {
        $tvUrl = $baseUrl . "tv/{$tmdbId}?api_key={$apiKey}&language={$lang}";
        $tvResponse = @file_get_contents($tvUrl);
        if ($tvResponse === false) {
            return null;
        }

        $tvData = json_decode($tvResponse, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        if (isset($tvData['id'])) {
            $title = $tvData['name'] ?? '';
            $year  = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
        }
    }

    return !empty($title) ? ['title' => $title, 'year' => $year] : null;
}

function getTitleAndYearTmdb($id, $season = null, $episode = null) {
    $apiKey  = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $lang    = 'en-EN';
    
    $title = '';
    $year  = '';

    if ($season && $episode) {
        $Url = $baseUrl . "tv/{$id}?api_key={$apiKey}&language={$lang}";
        $tvResponse = @file_get_contents($Url);

        if ($tvResponse === false) {
            return null;
        }

        $tvData = json_decode($tvResponse, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        $title = $tvData['name'] ?? '';
        $year  = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
    } else {
        $Url = $baseUrl . "movie/{$id}?api_key={$apiKey}&language={$lang}";
        $movieResponse = @file_get_contents($Url);

        if ($movieResponse === false) {
            return null;
        }

        $movieData = json_decode($movieResponse, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        $title = $movieData['title'] ?? '';
        $year  = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
    }

    return !empty($title) ? ['title' => $title, 'year' => $year] : null;
}

function isImdbId($id) {
    return preg_match('/^tt\d{7,9}$/', $id);
}

$title = '';

try {
    $info = isImdbId($id)
        ? getTitleAndYear($id, $season, $episode)
        : getTitleAndYearTmdb($id, $season, $episode);

    $title = $info['title'] ?? '';
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status"  => 500,
        "message" => "Error retrieving title info: " . $e->getMessage()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!$title) {
    http_response_code(404);
    echo json_encode([
        "status"  => 404,
        "message" => "Title not found"
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$result = ($season && $episode)
    ? searchTv($title)
    : searchMovie($title);

if (!$result) {
    http_response_code(404);
    echo json_encode([
        "status"  => 404,
        "message" => "Movie/TV show not found"
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$subjectId  = $result['subjectId'];
$detailPath = $result['detailPath'];

$result2 = ($season && $episode)
    ? getMovieStream($subjectId, $detailPath, $season, $episode)
    : getMovieStream($subjectId, $detailPath);

if (!$result2) {
    http_response_code(404);
    echo json_encode([
        "status"  => 404,
        "message" => "Stream not found"
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

header('Content-Type: application/json');
echo json_encode($result2, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

?>