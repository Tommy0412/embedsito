<?php
error_reporting(0);
set_time_limit(0);

ob_end_clean();

if (isset($_GET['data']) && !empty($_GET['data'])) {
    $decodedData = base64_decode($_GET['data']);
    $parts = explode('|', $decodedData);
    $url = array_shift($parts);
    $url = str_replace(",", "%2C", $url);

    $headers = [];
    foreach ($parts as $headerData) {
        list($header, $value) = explode('=', $headerData);
        $headers[] = "$header: $value";
    }

    if (isset($_SERVER['HTTP_RANGE'])) {
        $headers[] = "Range: " . $_SERVER['HTTP_RANGE'];
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);   
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_HEADER, true);

    $response = curl_exec($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        http_response_code(500);
        header('Content-Type: text/plain');
        //echo "cURL Error: " . curl_error($ch);
        curl_close($ch);
        exit;
    }

    $responseHeaders = substr($response, 0, $header_size);
    $body = substr($response, $header_size);

    curl_close($ch);

    $headersArray = explode("\r\n", $responseHeaders);
    foreach ($headersArray as $headerLine) {
        if (!empty($headerLine) && strpos($headerLine, ':') !== false) {
            header($headerLine);
        }
    }

    if (!in_array($statusCode, ['200', '206'])) {
        http_response_code($statusCode);
        header('Content-Type: text/plain');
        echo "Failed with status code: $statusCode";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'HEAD') {
        exit;
    }

    echo $body;
} else {
    http_response_code(400);
    header('Content-Type: text/plain');
    echo "Missing the data parameter.";
}
?>