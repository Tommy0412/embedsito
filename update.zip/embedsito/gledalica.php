<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

function getTitleAndYear($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $isMovie = false;
    $title = '';
    $year = '';

    $externalUrl = $baseUrl . "find/" . $id . "?api_key=" . $apiKey . "&external_source=imdb_id";
    $externalResponse = file_get_contents($externalUrl);
    $externalData = json_decode($externalResponse, true);

    if (isset($externalData['movie_results'][0]['id'])) {
        $tmdbId = $externalData['movie_results'][0]['id'];
        $isMovie = true;
    } elseif (isset($externalData['tv_results'][0]['id'])) {
        $tmdbId = $externalData['tv_results'][0]['id'];
    } else {
        return null;
    }

    if ($isMovie) {
        $movieUrl = $baseUrl . "movie/" . $tmdbId . "?api_key=" . $apiKey;
        $movieResponse = file_get_contents($movieUrl);
        $movieData = json_decode($movieResponse, true);

        if (isset($movieData['id'])) {
            $title = $movieData['title'];
            $year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
        }
    } else {
        $tvUrl = $baseUrl . "tv/" . $tmdbId . "?api_key=" . $apiKey;
        $tvResponse = file_get_contents($tvUrl);
        $tvData = json_decode($tvResponse, true);

        if (isset($tvData['id'])) {
        $title = $tvData['name'];
        $year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
        }
    }

    if (!empty($title)) {
        return [
            'title' => $title,
            'year' => $year
        ];
    } else {
        return null;
    }
}

function getTitleAndYearTmdb($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $title = '';
    $year = '';
    if ($season && $episode) {
    $Url = $baseUrl . "tv/" . $id . "?api_key=" . $apiKey;
	$tvResponse = file_get_contents($Url);
    $tvData = json_decode($tvResponse, true);
    $title = $tvData['name']; 
	$year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
	} else {
	$Url = $baseUrl . "movie/" . $id . "?api_key=" . $apiKey;
	$movieResponse = file_get_contents($Url);
    $movieData = json_decode($movieResponse, true);
    $title = $movieData['title']; 
	$year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
	}	
    if (!empty($title)) {
        return [
            'title' => $title,
            'year' => $year
        ];
	} else {
        return null;
    }
}

function getExactGledalicaUrl($title, $year) {
    $searchUrl = "https://gledalica.online/?s=" . urlencode($title);
    
    $html = @file_get_contents($searchUrl);
    if (!$html) {
        echo "Failed to fetch content from: $searchUrl<br>";
        return null;
    }

    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML($html);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);
    $items = $xpath->query('//div[@class="result-item"]');

    foreach ($items as $item) {
        $titleNode = $xpath->query('.//div[contains(@class,"details")]//div[contains(@class,"title")]/a', $item)->item(0);
        $yearNode = $xpath->query('.//div[contains(@class,"details")]//div[contains(@class,"meta")]/span[contains(@class,"year")]', $item)->item(0);
        $linkNode = $xpath->query('.//div[contains(@class,"thumbnail")]//a', $item)->item(0);

        if ($titleNode && $yearNode && $linkNode) {
            $foundTitle = trim(strtolower($titleNode->nodeValue));
            $foundYear = trim($yearNode->nodeValue);
            $url = $linkNode->getAttribute('href');

            //echo "Found: '$foundTitle' ($foundYear) → $url<br>";

            if ($foundTitle === strtolower($title) && $foundYear === $year) {
                return $url;
            }

            if (strpos($foundTitle, strtolower($title)) !== false && $foundYear === $year) {
                return $url;
            }
        } else {
            //echo "Missing elements in a result item.<br>";
        }
    }

    //echo "No match found.<br>";
    return null;
}

function isImdbId($id) {
    return preg_match('/^tt\d{7,9}$/', $id);
}

$id = isset($_GET['id']) ? $_GET['id'] : null;
$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

if (!$id) {
    echo json_encode(['error' => 'ID is required.']);
    exit;
}

if (isImdbId($id)) {
$call = getTitleAndYear($id, $season, $episode);
} else {
$call = getTitleAndYearTmdb($id, $season, $episode);
}

if ($call) {
    $title = $call['title'];
    $year = $call['year'];
    $url = getExactGledalicaUrl($title, $year);
}

function fetchInitialData($url, $season = null, $episode = null) {
    $html = getHtml($url);

    if ($season !== null && $episode !== null) {
        if (preg_match_all('/<div class=[\'"]se-c[\'"][^>]*>.*?<div class=[\'"]se-q[\'"]>.*?<span class=[\'"]se-t(?: se-o)?[\'"]>\s*(\d+)\s*<\/span>.*?<div class=[\'"]se-a[\'"]>\s*<ul class=[\'"]episodios[\'"]>(.*?)<\/ul>/is', $html, $seasonBlocks, PREG_SET_ORDER)) {
            foreach ($seasonBlocks as $block) {
                $seasonNum = (int)$block[1];
                $episodesHtml = $block[2];

                if ($seasonNum === (int)$season) {
                    if (preg_match_all('/<li class=[\'"]mark-(\d+)[\'"].*?<a href=[\'"](https:\/\/gledalica\.online\/episodes\/[^\'"]+)[\'"]/is', $episodesHtml, $episodeMatches, PREG_SET_ORDER)) {
                        foreach ($episodeMatches as $match) {
                            $epNum = (int)$match[1];
                            $epUrl = $match[2];

                            if ($epNum === (int)$episode) {
                                $html = getHtml($epUrl);
                                break 2;
                            }
                        }
                    }
                }
            }
        }
    }

    preg_match('/data-post=[\'"](\d+)[\'"]/i', $html, $post_match);
    $movie_id = $post_match[1] ?? "";

    preg_match('/id=[\'"]player-option-1[\'"][^>]*data-nume=[\'"](\d+)[\'"]/i', $html, $nume_match);
    $player_num = $nume_match[1] ?? "";

    preg_match('/id=[\'"]player-option-1[\'"][^>]*data-type=[\'"]([a-z]+)[\'"]/i', $html, $data_type_match);
    $data_type = $data_type_match[1] ?? "";

    return [$movie_id, $player_num, $data_type];
}

function getHtml($url) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9',
            'Sec-Fetch-Dest: document',
            'Sec-Fetch-Mode: navigate',
            'Sec-Fetch-Site: none',
            'Sec-Fetch-User: ?1',
            'Upgrade-Insecure-Requests: 1',
        ],
    ]);
    $html = curl_exec($ch);
    curl_close($ch);
    return $html;
}

function fetchIframeSrc($url, $movie_id, $player_num, $data_type) {
    $ajax_url = "https://gledalica.online/wp-admin/admin-ajax.php";
    $post_fields = http_build_query([
        'action' => 'doo_player_ajax',
        'post'   => $movie_id,
        'nume'   => $player_num,
        'type'   => $data_type,
    ]);

    $headers = [
        'Accept: */*',
        'Accept-Language: en-US,en;q=0.9',
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Origin: https://gledalica.online',
        'Referer: ' . $url,
        'Sec-Fetch-Dest: empty',
        'Sec-Fetch-Mode: cors',
        'Sec-Fetch-Site: same-origin',
        'X-Requested-With: XMLHttpRequest',
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $ajax_url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $post_fields,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        CURLOPT_ENCODING       => '',
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    if (empty($response)) return null;

    if (preg_match('/<iframe.*?src=["\'](.*?)["\']/i', $response, $matches)) {
        return $matches[1];
    }

    return null;
}


list($movie_id, $player_num, $data_type) = fetchInitialData($url, $season, $episode);
$iframe_src = fetchIframeSrc($url, $movie_id, $player_num, $data_type);

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$NEW_IFRAME_BASE = "{$protocol}{$host}/embedsito/netu/index.php?file=";

if ($iframe_src) {
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Player</title>
        <style>
        html, body, iframe {
            margin: 0;
            padding: 0;
            height: 100%;
            border: none;
        }
        iframe {
            display: block;
            width: 100%;
            border: none;
            overflow-y: auto;
            overflow-x: hidden;
        }
        </style>
    </head>
    <body>
<iframe src="' . $NEW_IFRAME_BASE . '' . $iframe_src . '" loading="lazy" scrolling="auto" frameborder="0" marginheight="0" marginwidth="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" width="100%" height="100%"></iframe>
    </body>
    </html>';
} else {
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <style>
        html, body, iframe {
            margin: 0;
            padding: 0;
            height: 100%;
            border: none;
        }
        iframe {
            display: block;
            width: 100%;
            border: none;
            overflow-y: auto;
            overflow-x: hidden;
        }
        .error-message {
        color: #dc3545;
        font-size: 24px;
        margin-bottom: 20px;
        }
        </style>
    </head>
    <body>
        <div class="error-message">No video source found</div>
    </body>
    </html>';
}
?>