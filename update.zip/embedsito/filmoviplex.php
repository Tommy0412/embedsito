<!DOCTYPE html>
<html>
<head>
<html lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>filmoviplex - Filmovi</title>
	<meta name="robots" content="noindex,nofollow">
<style type="text/css"> 
html 
{
 overflow: auto;
}
 
html, body, div, iframe 
{
 margin: 0px; 
 padding: 0px; 
 height: 100%; 
 border: none;
}

iframe 
{
 display: block; 
 width: 100%; 
 border: none; 
 overflow-y: auto; 
 overflow-x: hidden;
}
</style>
</head>
<body>
<?php
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');

$protocol =
    !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off"
        ? "https://"
        : "http://";
$host = $_SERVER["HTTP_HOST"];
$NEW_IFRAME_BASE = "{$protocol}{$host}/embedsito/netu/index.php?file=";
$searchParams = [];
parse_str($_SERVER["QUERY_STRING"], $searchParams);
$tmdbID = $searchParams["tmdb"] ?? null;

if (!$tmdbID) {
    die("tmdbID is not provided.");
}

function fetchDataWithCurl($url, $headers = [])
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $response = curl_exec($ch);
    curl_close($ch);
    return $response ? $response : null;
}

function fetchIframeSrc($html) {
    $dom = new DOMDocument();
    // Suppress warnings due to malformed HTML (if any)
    @$dom->loadHTML($html);

    // Get all anchor (<a>) elements
    $anchors = $dom->getElementsByTagName("a");

    foreach ($anchors as $anchor) {
        // Check if the anchor has an 'onclick' attribute
        if ($anchor->hasAttribute("onclick")) {
            $onclick = $anchor->getAttribute("onclick");

            // Extract the 'vid' parameter from the onclick attribute
            if (preg_match('/vid=([^"\']+)/', $onclick, $vidMatch)) {
                $encodedVid = $vidMatch[1];
                $decodedUrl = base64_decode($encodedVid);

                // Validate the decoded URL
                if ($decodedUrl && filter_var($decodedUrl, FILTER_VALIDATE_URL)) {
                    return $decodedUrl;
                }
            }
        }
    }

    // If no valid vid is found, return null
    return null;
}

$tmdb_url = "https://api.themoviedb.org/3/movie/$tmdbID?api_key=05902896074695709d7763505bb88b4d&language=en-US&external_source=imdb_id";
$tmdb_response = fetchDataWithCurl($tmdb_url);
$tmdb_data = json_decode($tmdb_response);

if ($tmdb_data) {
    global $NEW_IFRAME_BASE;
    $search = $tmdb_data->title;
    $year = $tmdb_data->release_date
        ? substr($tmdb_data->release_date, 0, 4)
        : "";

    $url =
        "https://www.filmoviplex.com/?all=all&s=" .
        urlencode($search) .
        "&orderby=all";

    $headers = [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Referer: https://www.filmoviplex.com/",
        "Origin: https://www.filmoviplex.com",
    ];

    $search_response = fetchDataWithCurl($url, $headers);

    if ($search_response) {
        if (
            preg_match_all(
                '#<a[^>]+title="([^"]+)"[^>]+href="([^"]+)"[^>]*>.*?<div>\s*([^<]+)\s*\((\d{4})\)</div>#si',
                $search_response,
                $matches,
                PREG_SET_ORDER
            )
        ) {
            foreach ($matches as $match) {
                $htmlTitle = trim($match[1]);
                $link = trim($match[2]); 
                $textTitle = trim($match[3]); 
                $htmlYear = trim($match[4]);

                if (
                    strcasecmp($htmlTitle, $search) === 0 &&
                    $htmlYear === $year
                ) {
                    $fetch_response = fetchDataWithCurl($link, $headers);
                    $iframe_src = fetchIframeSrc($fetch_response);

                    if (
                        !$iframe_src ||
                        !filter_var($iframe_src, FILTER_VALIDATE_URL)
                    ) {
                        exit("No valid iframe source found.");
                    }

                    echo '<iframe id="iframe" src="' .
                        $NEW_IFRAME_BASE .
                        "" .
                        htmlspecialchars($iframe_src) .
                        '" loading="lazy" scrolling="auto" frameborder="0" marginheight="0" marginwidth="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" width="100%" height="100%"></iframe>';
                    exit();
                }
            }
        }
    }
}

exit("No movie found.");
?>
</body>
</html>