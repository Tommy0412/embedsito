<?php 
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

function getVidsrc($tmdb_id, $s = null, $e = null) {
    $domain = "https://embed.su";
    $headers = [
        "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Referer: $domain",
        "Origin: $domain"
    ];

    $urlSearch = $s && $e ? "$domain/embed/tv/$tmdb_id/$s/$e" : "$domain/embed/movie/$tmdb_id";

    $htmlSearch = curlGet($urlSearch, $headers);
    if (!$htmlSearch) return null;

    preg_match('/JSON\.parse\(atob\(\`([^\`]+)/i', $htmlSearch, $hashEncodeMatch);
    $hashEncode = $hashEncodeMatch[1] ?? "";
    if (!$hashEncode) return null;

    $hashDecode = json_decode(stringAtob($hashEncode), true);
    $mEncrypt = $hashDecode['hash'] ?? null;
    if (!$mEncrypt) return null;

    $firstDecode = array_map(function($item) {
        return strrev($item);
    }, explode(".", stringAtob($mEncrypt)));

    $secondDecode = json_decode(stringAtob(strrev(implode("", $firstDecode))), true);
    if (empty($secondDecode)) return null;

    foreach ($secondDecode as $item) {
        if (strtolower($item['name']) != "viper") continue;

        $urlDirect = "$domain/api/e/" . $item['hash'];
        $dataDirect = json_decode(curlGet($urlDirect, [
            "Referer: $domain",
            "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept: */*"
        ]), true);

        if (empty($dataDirect['source'])) continue;

        $tracks = [];
        foreach ($dataDirect['subtitles'] as $itemTrack) {
            preg_match('/^([A-z]+)/i', $itemTrack['label'], $labelMatch);
            $label = $labelMatch[1] ?? "";
            if ($label) {
                $tracks[] = [
                    'src' => $itemTrack['file'],
                    'label' => $label,
					'kind' => "captions"
                ];
            }
        }

        $requestDirectSize = curlGet($dataDirect['source'], [
            "Referer: $domain",
            "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept: */*"
        ]);
        $parseDirectSize = explode("\n", $requestDirectSize);
        $directQuality = parsePlaylist($parseDirectSize);

        usort($directQuality, function($a, $b) {
            return $b['quality'] - $a['quality'];
        });

        if (empty($directQuality)) continue;

        return [
            'sources' => $directQuality,
            'subtitles' => $tracks
        ];
    }

    return null;
}

function parsePlaylist($parseDirectSize) {
    $sources = [];
    
    for ($i = 0; $i < count($parseDirectSize); $i++) {
        $line = $parseDirectSize[$i];
        
        if (strpos($line, '#EXT-X-STREAM-INF') !== false) {
            preg_match('/RESOLUTION=(\d+)x(\d+)/', $line, $resolutionMatch);
            preg_match('/BANDWIDTH=(\d+)/', $line, $bandwidthMatch);
            
            if (isset($resolutionMatch[2])) {
                $quality = (int)$resolutionMatch[2];
            } elseif (isset($bandwidthMatch[1])) {
                $quality = round((int)$bandwidthMatch[1] / 1000);  
            } else {
                $quality = 1080; 
            }
            
            $url = isset($parseDirectSize[$i + 1]) ? $parseDirectSize[$i + 1] : null;
			$url2 = isset($parseDirectSize[$i + 1]) ? $parseDirectSize[$i + 1] : null;
            
            if ($url) {
                $url = str_replace("/api/proxy/viper/", "", $url);
                $url = str_replace(".png", ".m3u8", $url);
                
                if (strpos($url, 'https://') === false) {
                    $url = 'https://' . $url; 
                }
                $embed_su_domain = "https://embed.su";
				$parsedUrl = parse_url($url);
                $domain = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
				if ($domain) {
                  $domain = 'https://' . $domain;
                }
				$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $hlsproxy = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . "/hls.php";
				//$proxiedUrl = $hlsproxy . "?url=" . urlencode($url) . "&origin=" . urlencode($domain) . "&referer=" . urlencode($domain);
				//$proxiedUrl = $hlsproxy . "?url=" . urlencode($url) . "&origin=" . urlencode($domain) . "&referer=" . urlencode($domain);
				$proxiedUrl = $hlsproxy . "?url=" . urlencode($url) . "&origin=https://kerolaunochan.live&referer=https://kerolaunochan.live/";
                $sources[] = [
				    'url' => $proxiedUrl,
					'url2' => $hlsproxy . "?url=" . $embed_su_domain . $url2 . "&origin=https://embed.su&referer=https://embed.su/",
                    'embed_su_original_hls' => $embed_su_domain . $url2,
                    'quality' => $quality,
                    'isM3U8' => strpos($url, '.m3u8') !== false
                ];
                $i++;
            }
        }
    }

    return $sources;
}

function curlGet($url, $headers = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function stringAtob($input) {
    return base64_decode($input);
}

$id = isset($_GET['id']) ? $_GET['id'] : null;
$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

if (!$id) {
	header('Content-Type: application/json');
    echo json_encode(['error' => 'ID is required.']);
    exit;
}

if ($season !== null && $episode !== null) {
$result = getVidsrc($id, $season, $episode);
} else {
$result = getVidsrc($id);
}
if ($result) {
    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);
} else {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No video sources or subtitles found.'], JSON_PRETTY_PRINT);
}

?>