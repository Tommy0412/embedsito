<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

function getRedirectedUrl($url) {
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Referer: https://mp4.nu/',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
    ]);
    
    curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        return 'cURL error: ' . curl_error($ch);
    }

    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    
    curl_close($ch);
    
    return $finalUrl;
}

function fetchExactMatchUrl($searchTerm) {
        $url = "https://www1.pelisforte.se/?s=" . urlencode($searchTerm);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36',
            'Origin: https://www1.pelisforte.se',
            'Referer: https://www1.pelisforte.se/'
        ]);

        $html = curl_exec($ch);

        if (curl_errno($ch)) {
            //echo "cURL error: " . curl_error($ch) . "";
            curl_close($ch);
            return null;
        }

        curl_close($ch);

        if ($html === false) {
            //echo "Failed to fetch the search page.";
            return null;
        }
    

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    @$dom->loadHTML($html);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);
    $query = "//div[@id='movies-a']//li[contains(@class, 'post')]/article/header/h2[text()='{$searchTerm}']/../../a/@href";
    $nodes = $xpath->query($query);

    if ($nodes->length > 0) {
        $finalUrl = $nodes->item(0)->nodeValue;

        return $finalUrl;
    } else {
        //echo "No matches found.<br>";
        return null;
    }
}

function getTmdbTitleFromImdbId($imdbId, $apiKey) {
    $url = "https://api.themoviedb.org/3/find/{$imdbId}?api_key={$apiKey}&external_source=imdb_id&language=es-MX";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
    ]);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        echo 'cURL Error: ' . curl_error($ch);
        return null;
    }
    
    curl_close($ch);
    
    $data = json_decode($response, true);
    
    if (isset($data['movie_results'][0]['title'])) {
        return $data['movie_results'][0]['title'];
    }
}	

function getTitleFromTmdbApi($tmdb, $apiKey) {
    $url = "https://api.themoviedb.org/3/movie/{$tmdb}?api_key={$apiKey}&language=es-MX";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
    ]);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        //echo 'cURL Error: ' . curl_error($ch);
        return null;
    }
    
    curl_close($ch);
    
    $data = json_decode($response, true);
    
    if (isset($data['title'])) {
        return $data['title'];
    }
}

$imdbId = isset($_GET['imdb']) ? $_GET['imdb'] : null;
$tmdb = isset($_GET['tmdb']) ? $_GET['tmdb'] : null;
$apiKey = '05902896074695709d7763505bb88b4d';

if ($imdbId) {
    $searchTerm = getTmdbTitleFromImdbId($imdbId, $apiKey);
} else {
    $searchTerm = getTitleFromTmdbApi($tmdb, $apiKey);
	//print_r($searchTerm);
}
    $url = fetchExactMatchUrl($searchTerm);
	//print_r($url);
    if ($url) {

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);  
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);   
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Referer: https://www1.pelisforte.se/'
    ]);

    $html = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        //die('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);

    if ($html === FALSE) {
        //die('Failed to fetch the page.');
    }

$dom = new DOMDocument();
libxml_use_internal_errors(TRUE);
@$dom->loadHTML($html);
libxml_clear_errors();

$xpath = new DOMXPath($dom);

$iframeQuery = '//section[contains(@class, "player")]//iframe/@data-src';
$nameQuery = '//section[contains(@class, "player")]//ul[contains(@class, "aa-tbs")]/li/a/span[@class="server"]';

$iframeNodes = $xpath->query($iframeQuery);
$nameNodes = $xpath->query($nameQuery);
}

if (isset($iframeNodes) && !empty($iframeNodes)) {
    $firstUrl = '';
    function getRedirectedUrlWithCache($rewrittenUrl) {
	global $searchTerm;
    $cacheFile = 'cache/' . $searchTerm . '.json';
    $cacheTime = 24 * 60 * 60;

    if (file_exists($cacheFile)) {
        $cache = json_decode(file_get_contents($cacheFile), true);
    } else {
        $cache = [];
    }

    if (isset($cache[$rewrittenUrl]) && (time() - $cache[$rewrittenUrl]['timestamp'] < $cacheTime)) {
        return $cache[$rewrittenUrl]['redirectedUrl'];
    }

    $redirectedUrl = getRedirectedUrl($rewrittenUrl);

    $cache[$rewrittenUrl] = [
        'redirectedUrl' => $redirectedUrl,
        'timestamp' => time() 
    ];

    file_put_contents($cacheFile, json_encode($cache));

    return $redirectedUrl;
}

require_once("JavaScriptUnpacker.php");

$urls = [];

foreach ($iframeNodes as $index => $iframeNode) {
    $url = $iframeNode->nodeValue;
    $rewrittenUrl = str_replace('mp4.nu/?h=', 'mp4.nu/r.php?h=', $url);
    $redirectedUrl = getRedirectedUrlWithCache($rewrittenUrl);

    $name = isset($nameNodes[$index]) ? $nameNodes[$index]->nodeValue : 'Unknown';
    $name = trim(preg_replace('/\s+/', ' ', $name));
    $host = $_SERVER['HTTP_HOST'];
    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    $baseUrl = 'http://' . $host . $scriptDir . '/';

    if (strpos($redirectedUrl, 'okhd.nu') !== false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $redirectedUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_ENCODING, "");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Referer: https://www1.pelisforte.se/',
            'Origin: https://www1.pelisforte.se',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36',
        ]);
        $h = curl_exec($ch);
        curl_close($ch);

        $out = "";
        if (preg_match("/eval\(function\(p,a,c,k,e,[r|d]?/", $h)) {
            $jsu = new JavaScriptUnpacker();
            preg_match_all("/eval\(function.*?\<\/script/s", $h, $m);
            for ($k = 0; $k < count($m[0]); $k++) {
                $out .= $jsu->Unpack($m[0][$k]);
            }
        }
        $out = $h . " " . $out;

        if (preg_match("/sources\:\s*\[\{file\:\"([^\"]+)\"/", $out, $m)) {
            $link = $m[1];
            $urls[] = [
                'name' => $name,
                'original_url' => $redirectedUrl,
                'm3u8_url' => $link,
            ];
        }
    }
}

header('Content-Type: application/json');
echo json_encode($urls, JSON_PRETTY_PRINT);
} else {
    echo "Not found";
}
?>