<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

function fetchHTML($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Referer: https://www2.pelisforte.se/'
    ]);

    $html = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        //die('cURL error: ' . curl_error($ch));
    }

    curl_close($ch);
    return $html;
}

function getRedirectedUrl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Referer: https://mp4.nu/',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
    ]);
    
    curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        //return 'cURL error: ' . curl_error($ch);
    }

    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    
    curl_close($ch);
    
    return $finalUrl;
}

function fetchExactMatchUrl($searchTerm) {
        $url = "https://www2.pelisforte.se/?s=" . urlencode($searchTerm);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36',
            'Origin: https://www2.pelisforte.se',
            'Referer: https://www2.pelisforte.se/'
        ]);

        $html = curl_exec($ch);

        if (curl_errno($ch)) {
            //echo "cURL error: " . curl_error($ch) . "";
            curl_close($ch);
            return null;
        }

        curl_close($ch);

        if ($html === false) {
            return null;
        }
    

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    @$dom->loadHTML($html);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);
    $query = "//div[@id='movies-a']//li[contains(@class, 'post')]/article/header/h2[text()='{$searchTerm}']/../../a/@href";
    $nodes = $xpath->query($query);

    if ($nodes->length > 0) {
        $finalUrl = $nodes->item(0)->nodeValue;

        return $finalUrl;
    } else {
        return null;
    }
}

function getTmdbTitleFromImdbId($imdbId, $apiKey) {
    $url = "https://api.themoviedb.org/3/find/{$imdbId}?api_key={$apiKey}&external_source=imdb_id&language=es-MX";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
    ]);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        //echo 'cURL Error: ' . curl_error($ch);
        return null;
    }
    
    curl_close($ch);
    
    $data = json_decode($response, true);
    
    if (isset($data['movie_results'][0]['title'])) {
        return $data['movie_results'][0]['title'];
    }
}	

function getTitleFromTmdbApi($tmdb, $apiKey) {
    $url = "https://api.themoviedb.org/3/movie/{$tmdb}?api_key={$apiKey}&language=es-MX";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
    ]);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        //echo 'cURL Error: ' . curl_error($ch);
        return null;
    }
    
    curl_close($ch);
    
    $data = json_decode($response, true);
    
    if (isset($data['title'])) {
        return $data['title'];
    }
}

function getRedirectedUrlWithCache($rewrittenUrl, $searchTerm) {
    $cacheFile = 'cache/' . $searchTerm . '.json';
    $cacheTime = 24 * 60 * 60; // Cache for 24 hours

    if (file_exists($cacheFile)) {
        $cache = json_decode(file_get_contents($cacheFile), true);
    } else {
        $cache = [];
    }

    if (isset($cache[$rewrittenUrl]) && (time() - $cache[$rewrittenUrl]['timestamp'] < $cacheTime)) {
        return $cache[$rewrittenUrl]['redirectedUrl'];
    }

    $redirectedUrl = getRedirectedUrl($rewrittenUrl);

    $cache[$rewrittenUrl] = [
        'redirectedUrl' => $redirectedUrl,
        'timestamp' => time()
    ];

    file_put_contents($cacheFile, json_encode($cache));

    return $redirectedUrl;
}

function get_url($host, $media_id) {
 return "https://$host/api/v1/video?id=$media_id";
}

function get_media_url($host, $media_id) {
    $web_url = get_url($host, $media_id);
	$host_url = "https://" . $host;
    $referer = parse_url($web_url, PHP_URL_SCHEME) . "://" . parse_url($web_url, PHP_URL_HOST) . "/";

    $headers = [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/126.0',
        'Referer: ' . $referer
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $web_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $edata = curl_exec($ch);
    curl_close($ch);

    if ($edata) {
        $edata = substr($edata, 0, -1); 
        $edata = hex2bin($edata);

        $key = hex2bin('6b69656d7469656e6d75613931316361'); //kiemtienmua911ca
        $iv  = hex2bin('313233343536373839306f6975797472'); //1234567890oiuytr

        $decrypted = openssl_decrypt($edata, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);

        if (!$decrypted) {
            //throw new Exception('Decryption failed.');
        }

        $ddata = json_decode($decrypted, true);
		
        //if (isset($ddata['source'])) {
            //return $ddata['source'];
        //}

        //if (isset($ddata['cf'])) {
         //return $ddata['cf'];
        //}
		if (isset($ddata['hls'])) {
		   return $host_url . $ddata['hls'];
		}
    }

    //throw new Exception('No playable video found.');
}

$imdbId = isset($_GET['imdb']) ? $_GET['imdb'] : null;
$tmdb = isset($_GET['tmdb']) ? $_GET['tmdb'] : null;
$apiKey = '05902896074695709d7763505bb88b4d';

if ($imdbId) {
    $searchTerm = getTmdbTitleFromImdbId($imdbId, $apiKey);
} else {
    $searchTerm = getTitleFromTmdbApi($tmdb, $apiKey);
}

$movieUrl = fetchExactMatchUrl($searchTerm);
	
if ($movieUrl) {
    $html = fetchHTML($movieUrl);

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    @$dom->loadHTML($html);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);

    $iframeQuery = '//section[contains(@class, "player")]//iframe/@data-src';
    $nameQuery = '//section[contains(@class, "player")]//ul[contains(@class, "aa-tbs")]/li/a/span[@class="server"]';

    $iframeNodes = $xpath->query($iframeQuery);
    $nameNodes = $xpath->query($nameQuery);

    if ($iframeNodes && $iframeNodes->length > 0) {

        $urls = [];

        foreach ($iframeNodes as $index => $iframeNode) {
            $url = $iframeNode->nodeValue;

            $name = isset($nameNodes[$index]) ? $nameNodes[$index]->nodeValue : 'Unknown';
            $name = trim(preg_replace('/\s+/', ' ', $name));

            // Skip anything that's not Okhd or W1tv
            if ($name !== 'Okhd -Español Latino' && $name !== 'W1tv -Español Latino') {
                continue;
            }

            $okhd = null;
            $w1tv = null;

            $rewrittenUrl = str_replace('mp4.nu/?h=', 'mp4.nu/r.php?h=', $url);
            $redirectedUrl = getRedirectedUrlWithCache($rewrittenUrl, md5($movieUrl));

            if ($name === 'Okhd -Español Latino' && strpos($redirectedUrl, 'okhd.nu') !== false) {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $redirectedUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_ENCODING, "");
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
                curl_setopt($ch, CURLOPT_TIMEOUT, 25);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Referer: https://mp4.nu/',
                    'Origin: https://mp4.nu',
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36',
                ]);
                $response = curl_exec($ch);
                curl_close($ch);

                require_once("JavaScriptUnpacker.php");
                $out = "";
                if (preg_match("/eval\(function\(p,a,c,k,e,[r|d]?/", $response)) {
                    $jsu = new JavaScriptUnpacker();
                    preg_match_all("/eval\(function.*?\<\/script/s", $response, $matches);
                    foreach ($matches[0] as $match) {
                        $out .= $jsu->Unpack($match);
                    }
                }
                $out = $response . " " . $out;

                if (preg_match("/sources\:\s*\[\{file\:\"([^\"]+)\"/", $out, $matches)) {
                    $okhd = $matches[1];
                }
            }

            if ($name === 'W1tv -Español Latino' && strpos($redirectedUrl, 'w1tv.xyz') !== false) {
                $parsedUrl = parse_url($redirectedUrl);
                $host = $parsedUrl['host'];
                $media_id = isset($parsedUrl['fragment']) ? $parsedUrl['fragment'] : null;

                if ($host && $media_id) {
                    $video_url = get_media_url($host, $media_id);
                    if ($video_url) {
                        $combineHeaders = '';
                        $combineHeaders .= '|Referer=' . $redirectedUrl;
                        $combineHeaders .= '|Origin=' . $redirectedUrl;
                        $combineHeaders .= '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/126.0';

                        		$scheme = 'http';

if (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') ||
    (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
) {
    $scheme = 'https';
}
                        $w1tv = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/hls_proxy1.php?url=' . urlencode($video_url) . '&data=' . base64_encode($combineHeaders);
                    }
                }
            }

$item = ['name' => $name];
if ($okhd !== null) {
    $item['okhd'] = $okhd;
}
if ($w1tv !== null) {
    $item['w1tv'] = $w1tv;
}
$urls[] = $item;
        }

        header('Content-Type: application/json');
        echo json_encode($urls, JSON_PRETTY_PRINT);
        exit;
    }
} else {
$urls = [];
echo json_encode($urls, JSON_PRETTY_PRINT);
exit;
}
?>