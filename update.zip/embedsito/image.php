<?php
$apiKey = '05902896074695709d7763505bb88b4d';
$id = $_GET['id'] ?? null;
$season = $_GET['season'] ?? null;
$episode = $_GET['episode'] ?? null;
$raw = isset($_GET['raw']); // For direct image request

if (!$id) {
    http_response_code(400);
    exit("Missing 'id' parameter.");
}

$thumbnailsDir = __DIR__ . '/thumbnails';
$thumbnailsUrlPath = 'thumbnails';

if (!file_exists($thumbnailsDir)) {
    mkdir($thumbnailsDir, 0755, true);
}

$isImdb = preg_match('/^tt\d+$/', $id);
if ($isImdb) {
    $tmdbData = json_decode(file_get_contents("https://api.themoviedb.org/3/find/$id?api_key=$apiKey&external_source=imdb_id"), true);
    if (!empty($tmdbData['movie_results'])) {
        $tmdbId = $tmdbData['movie_results'][0]['id'];
        $mediaType = 'movie';
    } elseif (!empty($tmdbData['tv_results'])) {
        $tmdbId = $tmdbData['tv_results'][0]['id'];
        $mediaType = 'tv';
    } else {
        http_response_code(404);
        exit; // Silent fail for JW
    }
} else {
    $tmdbId = $id;
    $mediaType = ($season && $episode) ? 'tv' : 'movie';
}

$cacheFileName = $tmdbId;
if ($mediaType === 'tv' && $season && $episode) {
    $cacheFileName .= "_s{$season}e{$episode}";
}
$cacheFile = "$thumbnailsDir/$cacheFileName.jpg";
$cacheUrl = "$thumbnailsUrlPath/$cacheFileName.jpg";

// Download and cache image if needed
if (!file_exists($cacheFile)) {
    $imagePath = null;

    if ($mediaType === 'movie') {
        $details = json_decode(file_get_contents("https://api.themoviedb.org/3/movie/$tmdbId?api_key=$apiKey"), true);
        $imagePath = $details['backdrop_path'] ?? null;
    } elseif ($mediaType === 'tv') {
        if ($season && $episode) {
            $details = json_decode(file_get_contents("https://api.themoviedb.org/3/tv/$tmdbId/season/$season/episode/$episode?api_key=$apiKey"), true);
            $imagePath = $details['still_path'] ?? null;
        } else {
            $details = json_decode(file_get_contents("https://api.themoviedb.org/3/tv/$tmdbId?api_key=$apiKey"), true);
            $imagePath = $details['poster_path'] ?? null;
        }
    }

    if ($imagePath) {
        $imageUrl = "https://image.tmdb.org/t/p/original$imagePath";
        $imageData = @file_get_contents($imageUrl);
        if ($imageData) {
            file_put_contents($cacheFile, $imageData);
        }
    }
}

// ✅ Direct image output for JWPlayer (raw mode)
if (file_exists($cacheFile)) {
    if ($raw) {
        header('Content-Type: image/jpeg');
        readfile($cacheFile);
        exit;
    }

    // ✅ HTML Fullscreen display (browser mode)
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Thumbnail</title>
        <style>
            html, body {
                margin: 0;
                padding: 0;
                background: black;
                height: 100%;
                overflow: hidden;
            }
            img {
                display: block;
                width: 100%;
                height: 100%;
                object-fit: contain;
                background-color: black;
            }
        </style>
    </head>
    <body>
        <img src="<?= htmlspecialchars($cacheUrl) ?>" alt="Thumbnail">
    </body>
    </html>
    <?php
} else {
    http_response_code(404);
    // ✅ Show black screen if no image found
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Not Found</title>
        <style>
            html, body {
                margin: 0;
                padding: 0;
                background: black;
                height: 100%;
                overflow: hidden;
            }
        </style>
    </head>
    <body></body>
    </html>
    <?php
}
?>