<!doctype html>
<?php
$l=$_GET['file'];
if (empty($l)) {
    die('<center><p style="color:#FFF000;">NOT FOUND</p></center>');
}

$l = preg_replace('~^(https?:)?//[^/]+~', 'https://hqq.to', $l);

$url_parts = parse_url($l);
$url_parts['host'] = "hqq.to";

$l = (isset($url_parts['scheme']) ? "{$url_parts['scheme']}:" : '') .
           ((isset($url_parts['user']) || isset($url_parts['host'])) ? '//' : '') .
           (isset($url_parts['user']) ? "{$url_parts['user']}" : '') .
           (isset($url_parts['pass']) ? ":{$url_parts['pass']}" : '') .
           (isset($url_parts['user']) ? '@' : '') .
           (isset($url_parts['host']) ? "{$url_parts['host']}" : '') .
           (isset($url_parts['port']) ? ":{$url_parts['port']}" : '') .
           (isset($url_parts['path']) ? "{$url_parts['path']}" : '') .
           (isset($url_parts['query']) ? "?{$url_parts['query']}" : '') .
           (isset($url_parts['fragment']) ? "#{$url_parts['fragment']}" : '');
echo '
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="custom.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<style>
#myId {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background-color: red;
  transition: 0.2s;
  position: absolute;
}
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: none; 
}
</style>
</head>
<body>
';
echo '<div id="myId"></div>';
echo "<a href='' id='mytest1'></a>";
//$host="https://".parse_url($l)['host'];
$host= "https://hqq.to";
$head=array('User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Referer: ' . rtrim($host, '/') . '/',
);
$l=str_replace("/f/","/e/",$l);

  //if (preg_match("/hash\=(\w+)/",$l,$m))
  //$l=$host."/e/".$m[1];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt($ch, CURLOPT_ENCODING, "");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
  curl_setopt($ch, CURLOPT_TIMEOUT, 15);
  $h = curl_exec($ch);
  curl_close($ch);
  //echo urldecode($h);
  //die();
  //if (preg_match("/file2sub\(\"([^\"]+)\"/",$h,$s)
if (preg_match('/file2sub\(\"([^\"]+)\"/', $h, $matches)) {
    $srt = $matches[1]; 
    $encodedSrt = base64_encode($srt); 
} else {
    $srt = ''; 
    $encodedSrt = ''; 
}

  preg_match("/orig_vid\s*\=\s*\"([^\"]+)\"/",$h,$m);
  $v=$m[1];
  preg_match("/\'videoid\'\:\s*\'([^\']+)\'/",$h,$m);
  $video_id=$m[1];
  preg_match("/\'videokey\'\:\s*\'([^\']+)\'/",$h,$m);
  $video_key=$m[1];
  preg_match("/adbn\s*\=\s*\'([^\']+)\'/",$h,$m);
  $adbn=$m[1];
  $post='{"videoid": "'.$video_id.'", "videokey": "'.$video_key.'", "width": 500, "height": 500}';
  //echo $post;
  //die();
  $l1=$host."/player/get_player_image.php";
  $head=array('User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Referer: '.$l,
  'Origin: '.$host,
  'Content-Type: application/json',
  'X-Requested-With: XMLHttpRequest'
  );
//echo $post;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch, CURLOPT_ENCODING, "");
  curl_setopt($ch, CURLOPT_POST,1);
  curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
  curl_setopt($ch, CURLOPT_TIMEOUT, 15);
  $h = curl_exec($ch);
  curl_close($ch);
  //echo $h;
  $r=json_decode($h,1);
  //print_r ($r);
  $hash_img=$r['hash_image'];
  $image=$r['image'];
  //echo '<center>Click on the triangle or move the red circle up/down, right/left, and press enter.</center><BR>';
  echo '<img src="'.$image.'">';

echo '
<script>
    var adbn = "' . $adbn . '"; 
    var hash_img = "' . $hash_img . '"; 
    var v = "' . $v . '"; 
    var link1 = ""; 
	var srtEncoded = "' . $encodedSrt . '";
	var ref = "' . $host . '";
	var origin = "' . $l . '";

    function test(x, y) { 
        $.post("hqq1.php", {
            adb: adbn,
            hash_img: hash_img,
            v: v,
            x: x,
            y: y
        }, function(data, status) {
            handleAjaxResponse(data); 
        });
    }

    function handleAjaxResponse(responseData) {
        //document.getElementById("rr").innerHTML = responseData; 
        link1 = responseData; 
		//console.log(link1);
		let encodedLink = btoa(link1);
        const myTimeout = setTimeout(() => myGO(encodedLink), 500);
    }

function myGO(encodedLink) {
	const redirectUrl = `link1.php?file=${encodedLink}&srt=${srtEncoded}&ref=${ref}&origin=${origin}`;
	window.location.href = redirectUrl;
}

    function on() {
        document.getElementById("overlay").style.display = "block";
    }

    function off() {
        document.getElementById("overlay").style.display = "none";
    }
';
echo '
document.onkeydown = detectKey;
function detectKey(e) {
    var posLeft = document.getElementById("myId").offsetLeft;
    var posTop = document.getElementById("myId").offsetTop;
    e = e || window.event;
    e.preventDefault();
    if (e.keyCode == "38") {
        document.getElementById("myId").style.marginTop  = (posTop-28)+"px";
    }
    else if (e.keyCode == "40") {
        document.getElementById("myId").style.marginTop  = (posTop+28)+"px";
    }
    else if (e.keyCode == "37") {
        document.getElementById("myId").style.marginLeft  = (posLeft-28)+"px";
    }
    else if (e.keyCode == "39") {
        document.getElementById("myId").style.marginLeft  = (posLeft+28)+"px";
    }
    else if (e.keyCode == "13") {
      test(posLeft,posTop);
    }
}

$(document).ready(function() {
    document.getElementById("myId").style.marginTop="200px";
    document.getElementById("myId").style.marginLeft="200px";
    $("img").on("click", function(event) {
        var x = event.pageX - this.offsetLeft;
        var y = event.pageY - this.offsetTop;
        test(x,y);
    });
});
</script>
';

echo '<div id="rr"></div>';
echo '
<div id="overlay">
  <div id="text">Wait....</div>
</div>
</body>
</html>
';
?>