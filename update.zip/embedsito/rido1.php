<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

$id = isset($_GET['id']) ? $_GET['id'] : null;
$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

if (!$id) {
	header('Content-Type: application/json');
    echo json_encode(['error' => 'ID is required.']);
    exit;
}

//ridoo.net
function getM3U8($iFrameURL) {
    $url = $iFrameURL;
	//echo $url;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_REFERER, 'https://ridomovies.tv/');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    curl_close($ch);

    preg_match_all('/<script[^>]*>(.*?)<\/script>/is', $data, $scriptTags);
    foreach ($scriptTags[1] as $scriptTag) {
        if (strpos($scriptTag, "jwplayer") !== false) {
            if (preg_match('/file:\s*"(.*?)"/', $scriptTag, $match)) {
				$combineHeaders = '';				
				$combineHeaders .= '|Referer=' . $iFrameURL;				
				$combineHeaders .= '|Origin=https://ridoo.net';
				$combineHeaders .= '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';				
				$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
				$sourceUrl = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/hls_proxy1.php?url=' . urlencode($match[1]) . '&data=' . base64_encode($combineHeaders);
				return $sourceUrl;
            }
        }
    }

    return null;
}

function extractValueParts($js) {
    $pattern = '/var\s+s_\w+\s*=\s*dc_\w+\s*\(\s*\[\s*(.*?)\s*\]\s*\)/s';
    if (preg_match($pattern, $js, $matches)) {
        $array_string = $matches[1];

        preg_match_all('/"([^"]+)"/', $array_string, $value_matches);
        return $value_matches[1];
    }

    return false;
}

function dc_XwDCXVCpLP9($value_parts) {
    $value = implode('', $value_parts);

    $result = str_rot13($value);

    $result = base64_decode($result);
    if ($result === false) return false;

    $result = strrev($result);

    $unmix = '';
    $modulus = 399756995;
    $len = strlen($result);

    for ($i = 0; $i < $len; $i++) {
        $charCode = ord($result[$i]);
        $charCode = ($charCode - ($modulus % ($i + 5)) + 256) % 256;
        $unmix .= chr($charCode);
    }

    return $unmix;
}


//closeload
function getStreamURL($id) {
    $url = "https://closeload.top/video/embed/$id/";
	//echo $url;
  $host="https://".parse_url($url)['host'];
  $head=array('User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept: application/json, text/plain, */*',
  'Accept-Language: ro-RO,ro;q=0.8,en-US;q=0.6,en-GB;q=0.4,en;q=0.2',
  'Accept-Encoding: deflate',
  'Origin: '.$host,
  'Connection: keep-alive',
  'Referer: '.$host);
    $ch = curl_init();
    //print_r($head);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    curl_setopt($ch, CURLOPT_HTTPHEADER,$head);
     $h = curl_exec($ch);
    //header("Content-Type: text/plain");
    //echo $h;
     curl_close($ch);
     //if (preg_match("/track\s+src\=\"([^\"]+)\"/",$h,$m))
      //$srt=$host.$m[1];
     //echo $srt;
  require_once("JavaScriptUnpacker.php");
  $jsu = new JavaScriptUnpacker();
  $out = $jsu->Unpack($h);
  //print_r($out);
   $value_parts = extractValueParts($out);
   //print_r($value_parts);
   if ($value_parts !== false) {
    $link = dc_XwDCXVCpLP9($value_parts);
	} 
  //echo $link;
				$combineHeaders = '';				
				$combineHeaders .= '|Referer=https://closeload.top/';				
				$combineHeaders .= '|Origin=https://closeload.top';
				$combineHeaders .= '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';				
				$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
if (isset($link) && !empty($link)) {
$sourceUrl = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . 
             '/hls_proxy1.php?url=' . urlencode($link) . '&data=' . base64_encode($combineHeaders);
} else {
    $sourceUrl = '';
}
	return $sourceUrl;
}

function fetchRidoTV($slug, $ep = null, $season = null) {
    $getIFrame = function($seasons, $season, $ep, $getM3U8) {
        if (!isset($seasons[$season - 1]) || !isset($seasons[$season - 1][$ep - 1])) {
            return 404;
        }
 $DEFAULT_CIPHERS =array(
            "ECDHE+AESGCM",
            "ECDHE+CHACHA20",
            "DHE+AESGCM",
            "DHE+CHACHA20",
            "ECDH+AESGCM",
            "DH+AESGCM",
            "ECDH+AES",
            "DH+AES",
            "RSA+AESGCM",
            "RSA+AES",
            "!aNULL",
            "!eNULL",
            "!MD5",
            "!DSS",
            "!ECDHE+SHA",
            "!AES128-SHA",
            "!DHE"
        );
 if (defined('CURL_SSLVERSION_TLSv1_3'))
  $ssl_version=7;
 else
  $ssl_version=0;

        $episodeId = $seasons[$season - 1][$ep - 1]['id'];
        $url = "https://ridomovies.tv/core/api/episodes/$episodeId/videos";
		//echo $episodeId;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
        curl_setopt($ch, CURLOPT_REFERER, 'https://ridomovies.tv/');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($ch, CURLOPT_ENCODING, ''); 
     	curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, implode(":", $DEFAULT_CIPHERS));
        curl_setopt($ch, CURLOPT_SSLVERSION,$ssl_version);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "accept: */*",
            "accept-language: en-US,en;q=0.9",
            "sec-ch-ua: \"Microsoft Edge\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"",
            "sec-ch-ua-mobile: ?0",
            "sec-ch-ua-platform: \"Windows\"",
        ]);

        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($response, true);
		//print_r($data);

        if (!isset($data['data'][0])) return 404;

        preg_match('/data-src="([^"]+)"/', $data['data'][0]['url'], $dataSrcMatch);
		//echo $dataSrcMatch[1];
        return isset($dataSrcMatch[1]) ? $getM3U8($dataSrcMatch[1]) : null;
    };

$getEpisodes = function($slug) use ($ep, $season, $getIFrame) {
    $url = "https://ridomovies.tv/tv/$slug";
			 $DEFAULT_CIPHERS =array(
            "ECDHE+AESGCM",
            "ECDHE+CHACHA20",
            "DHE+AESGCM",
            "DHE+CHACHA20",
            "ECDH+AESGCM",
            "DH+AESGCM",
            "ECDH+AES",
            "DH+AES",
            "RSA+AESGCM",
            "RSA+AES",
            "!aNULL",
            "!eNULL",
            "!MD5",
            "!DSS",
            "!ECDHE+SHA",
            "!AES128-SHA",
            "!DHE"
        );
 if (defined('CURL_SSLVERSION_TLSv1_3'))
  $ssl_version=7;
 else
  $ssl_version=0;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    curl_setopt($ch, CURLOPT_REFERER, 'https://ridomovies.tv/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, implode(":", $DEFAULT_CIPHERS));
    curl_setopt($ch, CURLOPT_SSLVERSION,$ssl_version);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $htmlContent = curl_exec($ch);
    curl_close($ch);

    if (!$htmlContent) {
        return null;
    }

    preg_match_all('/"episodes\\\\":\[(.*?)\]/', $htmlContent, $matches);
    if (empty($matches[1])) {
        return null;
    }

    $seasons = [];
    $seasonNumber = 1;

    foreach ($matches[1] as $match) {
        $cleanJson = str_replace(['\\"', '\\\\'], ['"', '\\'], $match);
        $episodesData = json_decode("[$cleanJson]", true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($episodesData)) {
            $seasonNumber++;
            continue;
        }

        $episodes = array_map(function($episode) use ($seasonNumber) {
            return [
                'id' => $episode['id'],
                'episodeNumber' => $episode['episodeNumber'],
                'season' => $seasonNumber,
            ];
        }, $episodesData);

        $seasons[] = $episodes;
        $seasonNumber++;
    } 

    if (isset($seasons[$season - 1]) && count($seasons[$season - 1]) >= $ep) {
        return $getIFrame($seasons, $season, $ep, 'getM3U8');
    }

    return 404;
};
	
    $getIframeID = function() use ($slug) {
        $url = "https://ridomovies.tv/movies/$slug";
		//echo $url;
		 $DEFAULT_CIPHERS =array(
            "ECDHE+AESGCM",
            "ECDHE+CHACHA20",
            "DHE+AESGCM",
            "DHE+CHACHA20",
            "ECDH+AESGCM",
            "DH+AESGCM",
            "ECDH+AES",
            "DH+AES",
            "RSA+AESGCM",
            "RSA+AES",
            "!aNULL",
            "!eNULL",
            "!MD5",
            "!DSS",
            "!ECDHE+SHA",
            "!AES128-SHA",
            "!DHE"
        );
 if (defined('CURL_SSLVERSION_TLSv1_3'))
  $ssl_version=7;
 else
  $ssl_version=0;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
        curl_setopt($ch, CURLOPT_REFERER, 'https://ridomovies.tv/');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, implode(":", $DEFAULT_CIPHERS));
        curl_setopt($ch, CURLOPT_SSLVERSION,$ssl_version);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $doc = curl_exec($ch);
        curl_close($ch);
        //echo htmlspecialchars($doc);
        if (preg_match('/data-video\s*=\s*"([^"]+)"/', $doc, $iframeIDMatch)) {
			//echo $iframeIDMatch[1];
            return getStreamURL($iframeIDMatch[1]);
        }

        return null;
    };

    return ($slug && $ep && $season) ? $getEpisodes($slug) : $getIframeID();
}

function fetchUrl($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15); 
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        //echo 'cURL error: ' . curl_error($ch);
    }
    curl_close($ch);
    return $response;
}

function getTitleAndYear($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $isMovie = false;
    $title = '';
    $year = '';

    $externalUrl = $baseUrl . "find/" . $id . "?api_key=" . $apiKey . "&external_source=imdb_id";
    $externalResponse = fetchUrl($externalUrl);
    $externalData = json_decode($externalResponse, true);

    if (isset($externalData['movie_results'][0]['id'])) {
        $tmdbId = $externalData['movie_results'][0]['id'];
        $isMovie = true;
    } elseif (isset($externalData['tv_results'][0]['id'])) {
        $tmdbId = $externalData['tv_results'][0]['id'];
    } else {
        return null;
    }

    if ($isMovie) {
        $movieUrl = $baseUrl . "movie/" . $tmdbId . "?api_key=" . $apiKey;
        $movieResponse = fetchUrl($movieUrl);
        $movieData = json_decode($movieResponse, true);

        if (isset($movieData['id'])) {
            $title = $movieData['title'];
            $year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
			$id = $movieData['id'];
        }
    } else {
        $tvUrl = $baseUrl . "tv/" . $tmdbId . "?api_key=" . $apiKey;
        $tvResponse = fetchUrl($tvUrl);
        $tvData = json_decode($tvResponse, true);

        if (isset($tvData['id'])) {
        $title = $tvData['name'];
        $year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
		$id = $tvData['id'];
        }
    }

    if (!empty($title)) {
        return [
            'title' => $title,
            'year' => $year,
			'id' => $id
        ];
    } else {
        return null;
    }
}

function getTitleAndYearTmdb($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $title = '';
    $year = '';
    if ($season && $episode) {
    $Url = $baseUrl . "tv/" . $id . "?api_key=" . $apiKey;
	$tvResponse = fetchUrl($Url);
    $tvData = json_decode($tvResponse, true);
    $title = $tvData['name']; 
	$year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : ''; 
	} else {
	$Url = $baseUrl . "movie/" . $id . "?api_key=" . $apiKey;
	$movieResponse = fetchUrl($Url);
    $movieData = json_decode($movieResponse, true);
    $title = $movieData['title']; 
	$year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
	}	
    if (!empty($title)) {
        return [
            'title' => $title,
            'year' => $year
        ];
	} else {
        return null;
    }
}

function isImdbId($id) {
    return preg_match('/^tt\d{7,9}$/', $id);
}

function getSlug($movieID, $movieName) {
    $formattedTitle = urlencode($movieName);
    $url = "https://ridomovies.tv/core/api/search?q=$formattedTitle";
 $DEFAULT_CIPHERS =array(
            "ECDHE+AESGCM",
            "ECDHE+CHACHA20",
            "DHE+AESGCM",
            "DHE+CHACHA20",
            "ECDH+AESGCM",
            "DH+AESGCM",
            "ECDH+AES",
            "DH+AES",
            "RSA+AESGCM",
            "RSA+AES",
            "!aNULL",
            "!eNULL",
            "!MD5",
            "!DSS",
            "!ECDHE+SHA",
            "!AES128-SHA",
            "!DHE"
        );
 if (defined('CURL_SSLVERSION_TLSv1_3'))
  $ssl_version=7;
 else
  $ssl_version=0;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'authority: ridomovies.tv',
        'path: /core/api/search?q=' . $formattedTitle,
        'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language: hr-HR,hr;q=0.9,en-US;q=0.8,en;q=0.7,und;q=0.6',
        'dnt: 1',
        'priority: u=0, i',
        'sec-ch-ua: "Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
        'sec-ch-ua-mobile: ?1',
        'sec-ch-ua-platform: "Android"',
        'sec-fetch-dest: document',
        'sec-fetch-mode: navigate',
        'sec-fetch-site: none',
        'sec-fetch-user: ?1',
        'upgrade-insecure-requests: 1',
        'user-agent: Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    ]);

    curl_setopt($ch, CURLOPT_REFERER, 'https://ridomovies.tv/');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_ENCODING, ''); 
	curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, implode(":", $DEFAULT_CIPHERS));
    curl_setopt($ch, CURLOPT_SSLVERSION,$ssl_version);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 25); 

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'cURL Error: ' . curl_error($ch);
    }

    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['data']['items'])) {
        foreach ($data['data']['items'] as $item) {
            if ($item['contentable']['tmdbId'] == $movieID) {
                return ['status' => 200, 'data' => $item['slug']];
            }
        }
    }

    return ['status' => 404];
}

$title = '';
$call1 = null;
$call2 = null;

    if (isImdbId($id)) {
        $call1 = getTitleAndYear($id, $season, $episode);
    } else {
        $call2 = getTitleAndYearTmdb($id, $season, $episode);
    }

if (!empty($call1)) {
    $title = $call1['title'] ?? '';
    $id = $call1['id'] ?? ''; 
} elseif (!empty($call2)) {
    $title = $call2['title'] ?? '';
}

$slugResult = getSlug($id, $title);

header('Content-Type: application/json');
if ($slugResult['status'] === 200) {
    $slug = $slugResult['data'];
	//echo $slug;
if ($season !== null && $episode !== null) {
    $mediaUrl = fetchRidoTV($slug, $episode, $season);
} else {
	$mediaUrl = fetchRidoTV($slug);
}
    if ($mediaUrl === 404) {
        echo json_encode([
            "status" => 404,
            "message" => "not found or unavailable."
        ]);
    } else {		  
        echo json_encode([
            "status" => 200,
            "hls" => $mediaUrl
        ]);
    }
} else {
    echo json_encode([
        "status" => 404,
        "message" => "not found."
    ]);
}

?>