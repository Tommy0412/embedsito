<?php
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');

const TMDB_API_KEY = '1428c4185bce6abd6564049d1351970d';
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];

$NEW_IFRAME_BASE = "{$protocol}{$host}/embedsito/netu/index.php?file=";

function fetchDataWithCurl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  
    curl_setopt($ch, CURLOPT_ENCODING, '');  
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.5',
        'DNT: 1',
        'Connection: keep-alive',
        'Upgrade-Insecure-Requests: 1',
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        //error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return null;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        //error_log("HTTP error: $httpCode for URL: $url");
        return null;
    }

    return $response;
}

function parseHtml($html) {
    if (empty($html)) {
        return null;
    }

    $doc = new DOMDocument();

    libxml_use_internal_errors(true);

    $html = mb_convert_encoding($html, 'UTF-8', 'auto');
    $html = '<?xml encoding="UTF-8">' . $html;

    @$doc->loadHTML($html);

    libxml_clear_errors();

    return $doc;
}

function fetchTmdbTitle($tmdbId, $season = null, $episode = null) {
    $url = $season && $episode
        ? "https://api.themoviedb.org/3/tv/$tmdbId?api_key=" . TMDB_API_KEY
        : "https://api.themoviedb.org/3/movie/$tmdbId?api_key=" . TMDB_API_KEY;

    $response = fetchDataWithCurl($url);

    if (!$response) {
        return null;
    }

    $data = json_decode($response, true);
    return $data['title'] ?? $data['name'] ?? null;
}

function fetchMovieIframe($movieUrl) {
	global $NEW_IFRAME_BASE;
    $response = fetchDataWithCurl($movieUrl);

    if (!$response) {
        return null;
    }

    $doc = parseHtml($response);

    $iframeLinkElement = $doc->getElementById('videoplayer');
    if (!$iframeLinkElement) {
        return null;
    }

    $originalIframeLink = $iframeLinkElement->getAttribute('href');

    if (!filter_var($originalIframeLink, FILTER_VALIDATE_URL)) {
        return null;
    }

    $url = parse_url($originalIframeLink);
    if (!$url || !isset($url['host'])) {
        return null;
    }

    $url['host'] = 'hqq.to';
    $iframeLink = http_build_url($url); 

    return $NEW_IFRAME_BASE . urlencode($iframeLink);
}

function fetchShowIframe($movieUrl, $season, $episode) {
	global $NEW_IFRAME_BASE;
    $response = fetchDataWithCurl($movieUrl);

    if (!$response) {
        return null;
    }

    $dom = parseHtml($response);

    $scriptTags = $dom->getElementsByTagName('script');
    $streaming = null;

    foreach ($scriptTags as $scriptTag) {
        $scriptContent = $scriptTag->textContent;
        if (preg_match('/var\s+streaming\s*=\s*({[^;]+});/', $scriptContent, $matches)) {
            $streaming = json_decode($matches[1], true);
            break;
        }
    }

    if (!$streaming) {
        return null;
    }

    $key = "s{$season}_{$episode}";

    if (isset($streaming[$key])) {
		
    if (!filter_var($streaming[$key], FILTER_VALIDATE_URL)) {
        return null;
    }

    $url = parse_url($streaming[$key]);
    if (!$url || !isset($url['host'])) {
        return null;
    }

    $url['host'] = 'hqq.to'; 
    $iframeLink = http_build_url($url);
	  return $NEW_IFRAME_BASE . urlencode($iframeLink);
    } else {
        echo "No iframe found";
    }
}

try {
    $urlParams = $_GET;
    $tmdbId = $urlParams['id'] ?? null;
    $season = $urlParams['season'] ?? null;
    $episode = $urlParams['episode'] ?? null;

    if (!$tmdbId) {
        throw new Exception('TMDB ID is required.');
    }

    $title = fetchTmdbTitle($tmdbId, $season, $episode);

    if (!$title) {
        throw new Exception('Title not found in TMDB.');
    }

    $searchUrl = "https://onlinesaprevodom.net/wp-json/wp/v2/search?search=" . urlencode($title) . "&per_page=100&page=1";
    $response = fetchDataWithCurl($searchUrl);

    if (!$response) {
        throw new Exception('Failed to fetch search results.');
    }

    $movies = json_decode($response, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON response: ' . json_last_error_msg());
    }

    if (empty($movies)) {
        throw new Exception('No search results found for the given title.');
    }

    $moviePageUrl = null;

    foreach ($movies as $movie) {
        if ($movie['title'] === $title) {
            $moviePageUrl = $movie['url'];
            break;
        }
    }

    if (!$moviePageUrl) {
        throw new Exception('Movie/TV show page not found.');
    }

    $finalIframeLink = null;

    if ($season && $episode) {
        $finalIframeLink = fetchShowIframe($moviePageUrl, $season, $episode);
    } else {
        $finalIframeLink = fetchMovieIframe($moviePageUrl);
    }

    if (!$finalIframeLink) {
        throw new Exception('Failed to fetch iframe link.');
    }

    echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>$title</title>
    <style>
        iframe {
            width: 100%;
            height: 100vh;
            border: none;
            position: fixed;
            top: 0;
            left: 0;
        }
    </style>
</head>
<body>
    <iframe id='movie-iframe' src='$finalIframeLink' loading='lazy' scrolling='auto' frameborder='0' marginheight='0' marginwidth='0' allowfullscreen='true'></iframe>
</body>
</html>";
} catch (Exception $e) {
    echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Error</title>
</head>
<body>
    <h1>Error</h1>
    <p>{$e->getMessage()}</p>
</body>
</html>";
}

function http_build_url($parsed_url) {
    $scheme   = isset($parsed_url['scheme']) ? $parsed_url['scheme'] . '://' : '';
    $host     = isset($parsed_url['host']) ? $parsed_url['host'] : '';
    $port     = isset($parsed_url['port']) ? ':' . $parsed_url['port'] : '';
    $user     = isset($parsed_url['user']) ? $parsed_url['user'] : '';
    $pass     = isset($parsed_url['pass']) ? ':' . $parsed_url['pass']  : '';
    $pass     = ($user || $pass) ? "$pass@" : '';
    $path     = isset($parsed_url['path']) ? $parsed_url['path'] : '';
    $query    = isset($parsed_url['query']) ? '?' . $parsed_url['query'] : '';
    $fragment = isset($parsed_url['fragment']) ? '#' . $parsed_url['fragment'] : '';
    return "$scheme$user$pass$host$port$path$query$fragment";
}