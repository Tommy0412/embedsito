<?php
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');

function getCurrentBaseUrl() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    return "$scheme://$host$path/";
}

$id = isset($_GET['id']) ? htmlspecialchars($_GET['id']) : die('Missing ID');
$season = isset($_GET['season']) ? (int)$_GET['season'] : null;
$episode = isset($_GET['episode']) ? (int)$_GET['episode'] : null;

$baseUrl = getCurrentBaseUrl();

$apiUrl = $baseUrl . "/zoechip.php?tmdb=$id";
if ($season !== null && $episode !== null) {
    $apiUrl .= "&season=" . $season . "&episode=" . $episode;
	//echo $apiUrl;
}

$response = fetchDataWithCurl($apiUrl);

if (!$response) {
    die('Failed to fetch data from the API.');
}

$data = json_decode($response, true);

if (!isset($data['doodstream']) || empty($data['doodstream'])) {
    die('No doodstream URL found.');
}

$scheme1 = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$subtitles = [];

$apiUrl2 = $baseUrl . "subtitles.php?id=$id";
if ($season !== null && $episode !== null) {
    $apiUrl2 .= "&season=" . $season . "&episode=" . $episode;
}
//echo $apiUrl2;
$response2 = fetchDataWithCurl($apiUrl2);
    
if ($response2) {
$subtitles1 = json_decode($response2, true);
                            foreach ($subtitles1 as $track) {
                                $subtitles[] = [
									'src' => $track['file'], 
                                    'label' => $track['label'],
                                    'kind' => $track['kind']
                                ];
                            }
}
//print_r($response2);
$filelink = $data['doodstream'];
//echo $filelink;

function fetchDataWithCurl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        //error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        //error_log("HTTP error: $httpCode for URL: $url");
        return false;
    }

    return $response;
}

function makePlay($filelink) {
   $a = "";
   $t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
   $n = strlen($t) - 1;

   for ($o = 0; $o < 10; $o++) {
       $a .= $t[rand(0, $n)];
   }

   $filelink = str_replace("/f/", "/e/", $filelink);
   $filelink = str_replace("/d/", "/e/", $filelink);
   $host = parse_url($filelink)['host'];

   /* SSL Cipher List for preventing Cloudflare captcha */
   $DEFAULT_CIPHERS = array(
       "ECDHE+AESGCM",
       "ECDHE+CHACHA20",
       "DHE+AESGCM",
       "DHE+CHACHA20",
       "ECDH+AESGCM",
       "DH+AESGCM",
       "ECDH+AES",
       "DH+AES",
       "RSA+AESGCM",
       "RSA+AES",
       "!aNULL",
       "!eNULL",
       "!MD5",
       "!DSS",
       "!ECDHE+SHA",
       "!AES128-SHA",
       "!DHE"
   );

   //$ssl_version = (defined('CURL_SSLVERSION_TLSv1_3')) ? 7 : 0;
   //$ssl_version = (defined('CURL_SSLVERSION_TLSv1_3')) ? CURL_SSLVERSION_TLSv1_3 : 0;
   $ssl_version = (defined('CURL_SSLVERSION_TLSv1_1')) ? CURL_SSLVERSION_TLSv1_3 : 0;

   $ua = "Mozilla/5.0 (Windows NT 10.0; rv:89.0) Gecko/20100101 Firefox/89.0";

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $filelink);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, $ua);
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
   curl_setopt($ch, CURLOPT_ENCODING, "");
   curl_setopt($ch, CURLOPT_HEADER, 1);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
   curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, implode(":", $DEFAULT_CIPHERS));
   curl_setopt($ch, CURLOPT_SSLVERSION, $ssl_version);
   curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
   curl_setopt($ch, CURLOPT_TIMEOUT, 25);

   $h = curl_exec($ch);
   //var_dump($h);
   curl_close($ch);

   if (preg_match_all("/location\:\s+(http.+)/i", $h, $m)) {
       $filelink = trim($m[1][count($m[1]) - 1]);
       $host = parse_url($filelink)['host'];
   }

   if (preg_match('/(\/\/[\.\d\w\-\.\/\\\:\?\&\#\%\_\,]*(\.(srt|vtt)))/', $h, $s)) {
       $srt = "https:" . $s[1];
   }

   $link = ""; 
   if (preg_match("/pass_md5/", $h)) {
       $t1 = explode('token=', $h);
       $t2 = explode('&', $t1[1]);
       $tok = $t2[0];

       $t1 = explode("pass_md5/", $h);
       $t2 = explode("'", $t1[1]);
       $l = "https://" . $host . "/pass_md5/" . $t2[0];

       $head = array(
           'Accept: */*',
           'Accept-Language: en-US,en;q=0.8,en-US;q=0.6,en-GB;q=0.4,en;q=0.2',
           'Accept-Encoding: deflate',
           'X-Requested-With: XMLHttpRequest',
           'Alt-Used: dood.re:443',
           'Connection: keep-alive',
           'Cookie: referer=',
           'Referer: ' . $filelink
       );

       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $l);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_USERAGENT, $ua);
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
       curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, implode(":", $DEFAULT_CIPHERS));
       curl_setopt($ch, CURLOPT_SSLVERSION, $ssl_version);
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
       curl_setopt($ch, CURLOPT_TIMEOUT, 25);

       $h1 = curl_exec($ch);
       curl_close($ch);

       if (preg_match("/http/", $h1) && substr($h1, 0, 4) == "http") {
           $link = $h1 . "?token=" . $tok . "&expiry=" . (time() * 1000);
       }
   }

   return $link;
}

$extractedLink = makePlay($filelink);

?>
<?php if (isset($extractedLink) && !empty($extractedLink)) { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Player</title>

    <!-- Load Plyr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/plyr@3.7.8/dist/plyr.css" />

    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: #000;
        }

        #player-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
        }

        video#player {
            width: 100%;
            height: 100%;
            object-fit: cover; 
        }

        .plyr {
            height: 100%;
        }

        .plyr__controls {
            opacity: 1 !important;
            visibility: visible !important;
            transition: none !important;
        }

        .plyr .plyr__captions .plyr__caption {
            color: yellow !important; /* Yellow text */
            background-color: rgba(0, 0, 0, 0.8) !important; /* Black background with 80% opacity */
            font-size: 18px !important; /* Font size */
            font-family: Arial, sans-serif !important; /* Font family */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7) !important; /* Text shadow */
            padding: 5px !important; /* Padding */
        }

        /* Responsive font size for larger screens */
        @media (min-width: 1024px) {
            .plyr .plyr__captions .plyr__caption {
                font-size: 24px !important; /* Larger font size for big screens */
            }
        }
    </style>
</head>

<body>
    <div id="player-container">
        <video id="player" playsinline controls>
            <source src="<?= $extractedLink ?>" type="video/mp4" />

            <!-- Subtitles track setup -->
            <?php foreach ($subtitles as $index => $sub): ?>
                <track
                    src="<?= $sub['src']; ?>"
                    kind="captions"
                    srclang="<?= $sub['lang'] ?? 'en'; ?>"
                    label="<?= $sub['label'] ?? 'Subtitle ' . ($index + 1); ?>"
                    <?= $index === 0 ? 'default' : ''; ?>
                />
            <?php endforeach; ?>
        </video>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/plyr@3.7.8/dist/plyr.min.js"></script>

    <script>
        const player = new Plyr('#player', {
            controls: [
                'play-large', 'play', 'progress', 'current-time', 'duration',
                'mute', 'volume', 'captions', 'settings', 'fullscreen'
            ],
            settings: ['captions', 'speed', 'loop'],
            autoplay: false,
			preload: 'none',
            captions: { active: true, update: true, language: 'en' }
        });

        player.on('loadeddata', () => console.log("✅ Video loaded successfully."));
        player.on('error', (e) => console.error("❌ Error with video playback:", e));
    </script>

</body>
</html>
<?php } else { ?>
<center><p style="color:#FFF000;">NOT FOUND</p></center>
<?php } ?>