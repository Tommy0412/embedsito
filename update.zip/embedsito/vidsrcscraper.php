<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

function getCurrentBaseUrl1() {
		$scheme = 'http://';

if (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') ||
    (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
) {
    $scheme = 'https://';
}
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    return "$scheme$host$path/";
}

function http_get($url, $headers) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function getVideoSource($id, $season = null, $episode = null) {
if ($season !== null && $episode !== null) {
$base_url = "https://vidsrc.xyz/embed/tv/$id/$season-$episode";
} else {
$base_url = "https://vidsrc.xyz/embed/movie/$id";
}

$user_agent = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36";
$parsed_url = parse_url($base_url);
$default_domain = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/";
$headers = [
    "Referer: " . $default_domain,
    "User-Agent: " . $user_agent,
];

$response = http_get($base_url, $headers);

libxml_use_internal_errors(true); 
$dom = new DOMDocument();
$dom->loadHTML($response);
$xpath = new DOMXPath($dom);

$iframe_node = $xpath->query("//iframe[@id='player_iframe']")->item(0);
if (!$iframe_node) {
    $response = http_get($base_url, $headers);
    $dom->loadHTML($response);
    $xpath = new DOMXPath($dom);
    $iframe_node = $xpath->query("//iframe[@id='player_iframe']")->item(0);
    $rcp_iframe = "https:" . $iframe_node->getAttribute('src');
} else {
    $rcp_iframe = "https:" . $iframe_node->getAttribute('src');
}

$response = http_get($rcp_iframe, $headers);
preg_match("/src:\s*'([^']+)'/", $response, $matches);
$prorcp_iframe = $matches[1];
$parsed_url = parse_url($rcp_iframe);
$default_domain = $parsed_url['scheme'] . "://" . $parsed_url['host'] . "/";
$final_iframe = $default_domain . ltrim($prorcp_iframe, '/');
//echo $final_iframe;
$response = http_get($final_iframe, $headers);
//print_r($response);
$headers[] = "Referer: " . $default_domain;
preg_match("/file:\s*'([^']+)'/", $response, $matches);
if (!isset($matches[1])) {
    return null; 
}
$baseUrl = getCurrentBaseUrl1();
$video_url = $matches[1];
				$combineHeaders = '';				
				$combineHeaders .= '|Referer=' . $default_domain;				
				//$combineHeaders .= '|Origin=' . $default_domain;
				$combineHeaders .= '|User-Agent=Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36';		
		$scheme = 'http';

if (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') ||
    (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
) {
    $scheme = 'https';
}
    $scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/';
    $scriptDir = str_replace('\/', '/', $scriptDir); 
    $sourceUrl = $scheme . "://" . $_SERVER['HTTP_HOST'] . $scriptDir . 'hls_proxy007.php?url=' . urlencode($video_url) . '&data=' . base64_encode($combineHeaders);	
   return $sourceUrl;
}	
?>