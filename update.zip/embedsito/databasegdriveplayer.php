<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

require_once 'CryptoJSAES.php';

function decryptCryptoJsAes($json, $passphrase) {
    $obj = json_decode($json, true);
    if (!isset($obj['ct'], $obj['iv'], $obj['s'])) {
        throw new Exception("Invalid input format");
    }

    $ct = base64_decode($obj['ct']);
    $salt = hex2bin($obj['s']);
    $iv = hex2bin($obj['iv']);

    $opensslFormatted = base64_encode("Salted__" . $salt . $ct);

    return CryptoJSAES::decrypt($opensslFormatted, $passphrase);
}

function decsojson4($jsf) {
    $head = "['sojson.v4']";
    
    if (strpos($jsf, $head) === false) {
        return "Failed!\nGiven code is not encoded as Sojson v4.";
    }
    
    $substring = substr($jsf, 240, strlen($jsf) - 240 - 58);
    $args = preg_split('/[a-zA-Z]{1,}/', $substring);
    
    $str = "";
    foreach ($args as $arg) {
        if (is_numeric($arg)) {
            $str .= chr((int)$arg);
        }
    }
    
    return $str;
}

function getStreamURL($url) {
    $host = "https://" . parse_url($url)['host'];
    $head = array(
        'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept: application/json, text/plain, */*',
        'Accept-Language: ro-RO,ro;q=0.8,en-US;q=0.6,en-GB;q=0.4,en;q=0.2',
        'Origin: ' . $host,
        'Referer: ' . $host
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);

    $h = curl_exec($ch);
    curl_close($ch);

    require_once("JavaScriptUnpacker.php");
    $jsu = new JavaScriptUnpacker();
    $out = $jsu->Unpack($h);

    if (!str_contains($out, "var data='")) return [];
    $eval1 = explode("var data='", $out)[1];
    $eval = explode("';", $eval1)[0];
	//get passphrase
	//$sojsonv4_code = explode("';", $eval1)[1];
	//$decryptedsojsonv4_code = decsojson4($sojsonv4_code);
	//preg_match('/var\s+pass\s*=\s*"([^"]+)"/', $decryptedsojsonv4_code, $matches);
    //$passphrase = $matches[1] ?? null;
	//echo $passphrase;

    $passphrase = "alsfheafsjklNIWORNiolNIOWNKLNXakjsfwnBdwjbwfkjbJjkopfjweopjASoiwnrflakefneiofrt";
    $decryptedData = decryptCryptoJsAes($eval, $passphrase);

    $out2 = $jsu->Unpack($decryptedData);

    preg_match_all('/\{\s*"file"\s*:\s*"([^"]+)",\s*"label"\s*:\s*"([^"]+)"/', $out2, $matches);

    $result = [];

    if (!empty($matches) && count($matches) >= 3) {
        $files = $matches[1];  // URLs
        $labels = $matches[2]; // Quality labels (e.g., "720p")

        $gdplayerurl = "https://databasegdriveplayer.xyz/";

        foreach ($files as $i => $file) {
							$combineHeaders = '';				
				$combineHeaders .= '|Referer=' . $url;				
				$combineHeaders .= '|Origin=' . $url;
				$combineHeaders .= '|User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';				
				$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
				$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/';
                $scriptDir = str_replace('\/', '/', $scriptDir); 
				$sourceUrl = $scheme . "://" . $_SERVER['HTTP_HOST'] . $scriptDir . 'hls_proxy0.php?url=' . urlencode($gdplayerurl . $file) . '&data=' . base64_encode($combineHeaders);

			$result[] = [
                'quality' => $labels[$i],
                //'url' => $gdplayerurl . $file
				'url' => $sourceUrl
            ];
        }
    }

    return $result;
}

function isImdbId($id) {
    return preg_match('/^tt\d{7,9}$/', $id);
}

$id = $_GET['id'] ?? null;
$season = $_GET['season'] ?? null;
$episode = $_GET['episode'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(["error" => "Missing 'id' parameter."]);
    exit;
}

if ($season && $episode) {
    if (isImdbId($id)) {
        $gdurl = "https://series.databasegdriveplayer.co/player.php?type=series&imdb=$id&season=$season&episode=$episode";
    } else {
        $gdurl = "https://series.databasegdriveplayer.co/player.php?type=series&tmdb=$id&season=$season&episode=$episode";
    }
} else {
    if (isImdbId($id)) {
        $gdurl = "https://databasegdriveplayer.xyz/player.php?imdb=$id";
    } else {
        $gdurl = "https://databasegdriveplayer.co/player.php?tmdb=$id";
    }
}
$data = getStreamURL($gdurl);
header('Content-Type: application/json');
echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>