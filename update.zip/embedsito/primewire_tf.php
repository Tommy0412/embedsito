<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

$tmdbId = isset($_GET['id']) ? htmlspecialchars($_GET['id']) : die('Missing ID');
$season = isset($_GET['season']) ? (int)$_GET['season'] : null;
$episode = isset($_GET['episode']) ? (int)$_GET['episode'] : null;

header("Content-type: application/json; charset=utf-8");

function makeGetRequest($url, $referer = null, $additionalHeaders = [], $timeOut = 15) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeOut);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  

    $headers = [
        "Accept: */*",
        "Accept-Language: en-US,en;q=0.5",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/126.0"
    ];

    if ($referer) {
        $headers[] = "Referer: $referer";
    }

    if (!empty($additionalHeaders)) {
        $headers = array_merge($headers, $additionalHeaders);
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        return false;
    }
    curl_close($ch);

    return $response;
}

function decryptPWuserData1($encryptedData) {
    if (!$encryptedData) {
        return null;
    }

    $key = substr($encryptedData, -10);
    $encryptedData = substr($encryptedData, 0, -10);
    $data = base64_decode($encryptedData);
    if ($data === false) {
        return null;
    }

    $opts = OPENSSL_RAW_DATA | OPENSSL_DONT_ZERO_PAD_KEY | OPENSSL_ZERO_PADDING;
    $decrypted = openssl_decrypt($data, 'BF-ECB', $key, $opts);
    if ($decrypted === false) {
        return null;
    }

    $keys = str_split($decrypted, 5);
    return $keys;
}

require_once 'phpseclib/Crypt/Base.php';
require_once 'phpseclib/Crypt/Blowfish.php';

use phpseclib\Crypt\Blowfish;

function decryptPWuserData($encryptedData) {
    if (!$encryptedData) {
        return null;
    }

    $key = substr($encryptedData, -10);
    $encryptedData = substr($encryptedData, 0, -10);

    $data = base64_decode($encryptedData);
    if ($data === false) {
        return null;
    }

    $blowfish = new Blowfish(Blowfish::MODE_ECB);
    $blowfish->setKey($key);
    $blowfish->disablePadding(); 

    $decrypted = $blowfish->decrypt($data);

    if ($decrypted === false) {
        return null;
    }

    $keys = str_split($decrypted, 5);
    return $keys;
}

function fetchDataWithCurl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        //error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        //error_log("HTTP error: $httpCode for URL: $url");
        return false;
    }

    return $response;
}

function primewire_tf($tmdbId) {
    $primeWireDomain = 'https://www.primewire.tf';
	global $season;
	global $episode;
	
	if ($season !== null && $episode !== null) {
	$apiUrl = "https://www.primewire.tf/embed/tv?tmdb=" . $tmdbId . "&season=" . $season . "&episode=" . $episode;
	} else {	
    $apiUrl = "$primeWireDomain/embed/movie?tmdb=$tmdbId";
	}

    try {
        $response = makeGetRequest($apiUrl);
        if ($response === false) {
            return false;
        }
    } catch (Exception $error) {
        return false;
    }

    try {
        if (preg_match('/(?<="user-data" v=").*?(?=")/', $response, $userData)) {
            $keys = decryptPWuserData($userData[0]);
            if ($keys === false) {
                return false;
            }
        } else {
            return false;
        }

        $matches1 = [];
        $matches2 = [];

        $pattern1 = '/(?<=\#\d\s-\s).*?(?=[\s\(|"])/';
        $pattern2 = '/(?<=\#\d{2}\s-\s).*?(?=[\s\(|"])/';

        preg_match_all($pattern1, $response, $matches1);
        preg_match_all($pattern2, $response, $matches2);

        $matches = array_merge($matches1[0], $matches2[0]);

        if (empty($matches)) {
            return false;
        }

        $counter = 0;
        $filelions_to = $streamwish_to = $mixdrop_ag = $voe_sx = $dood = $vidmoly = null;

        $allowed_values = ["filelions.to", "streamwish.to", "mixdrop.ag", "voe.sx", "dood.watch", "vidmoly.me"];
        
        foreach ($matches as $match) {
            if (isset($keys[$counter]) && in_array($match, $allowed_values)) {
                if (($match == "filelions.to" && !$filelions_to) ||
                    ($match == "streamwish.to" && !$streamwish_to) ||
                    ($match == "mixdrop.ag" && !$mixdrop_ag) ||
                    ($match == "voe.sx" && !$voe_sx) ||
					($match == "vidmoly.me" && !$vidmoly) ||
					($match == "dood.watch" && !$dood)) {	

                    $hostUrl = "$primeWireDomain/links/go/{$keys[$counter]}?embed=true";
					$response = fetchDataWithCurl($hostUrl);

                    if ($response === false) {
                        return null;
                    }

                    $data = json_decode($response, true);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        return null;
                    }

                    $finalUrl = $data['link'] ?? null;

                    switch ($match) {
                        case "filelions.to":
                            if (!$filelions_to) $filelions_to = $finalUrl;
                            break;
                        case "streamwish.to":
                            if (!$streamwish_to) $streamwish_to = $finalUrl;
                            break;
                        case "mixdrop.ag":
                            if (!$mixdrop_ag) $mixdrop_ag = $finalUrl;
                            break;
                        case "voe.sx":
                            if (!$voe_sx) $voe_sx = $finalUrl;
                            break;
						case "dood.watch":
                            if (!$dood) $dood = $finalUrl;
                            break;	
						case "vidmoly.me":
                            if (!$vidmoly) $vidmoly = $finalUrl;
                            break;							
                    }
                }
            }
            $counter++;
        }

        $results = [];
        if (!empty($dood)) {
            $results['dood'] = $dood;
        }
        if (!empty($filelions_to)) {
            $results['filelions_to'] = $filelions_to;
        }
        if (!empty($streamwish_to)) {
            $results['streamwish_to'] = $streamwish_to;
        }
        if (!empty($mixdrop_ag)) {
            $results['mixdrop_ag'] = $mixdrop_ag;
        }
        if (!empty($voe_sx)) {
            $results['voe_sx'] = $voe_sx;
        }
		if (!empty($vidmoly)) {
            $results['vidmoly'] = $vidmoly;
        }

        return !empty($results) ? $results : "";
        
    } catch (Exception $error) {
        //return false;
    }
}

$result = primewire_tf($tmdbId);
//print_r($result);
if ($result !== false) {
	$dood = isset($result['dood']) ? $result['dood'] : '';
	$vidmoly = isset($result['vidmoly']) ? $result['vidmoly'] : '';
	$filelions_to = isset($result['filelions_to']) ? $result['filelions_to'] : '';
	$mixdrop_ag = isset($result['mixdrop_ag']) ? $result['mixdrop_ag'] : '';
	$streamwish_to = isset($result['streamwish_to']) ? $result['streamwish_to'] : ''; 
	$voe_sx = isset($result['voe_sx']) ? $result['voe_sx'] : ''; 
} else {
	$filelions_to ="";
	$mixdrop_ag ="";
	$streamwish_to ="";
	$voe_sx ="";
	$dood ="";
	$vidmoly ="";
}	

$data[] = array(
    		"vidhide"=>$filelions_to,
    		"streamwish"=>$streamwish_to,
			"mixdrop"=>$mixdrop_ag,
			"voesx"=>$voe_sx,
			"dood"=>$dood,
			"vidmoly"=>$vidmoly
    	);
$json = json_encode($data);
if ($json === false) {
    $json = json_encode(["jsonError" => json_last_error_msg()]);
    if ($json === false) {
        $json = '{"jsonError":"unknown"}';
    }
    http_response_code(500);
}
echo $json;	
exit;	
?>