<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

$tmdbId = isset($_GET['id']) ? htmlspecialchars($_GET['id']) : die('Missing ID');
$season = isset($_GET['season']) ? (int)$_GET['season'] : null;
$episode = isset($_GET['episode']) ? (int)$_GET['episode'] : null;

header("Content-type: application/json; charset=utf-8");

function makeGetRequest($url, $referer = null, $additionalHeaders = [], $timeOut = 15) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeOut);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  

    $headers = [
        "Accept: */*",
        "Accept-Language: en-US,en;q=0.5",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/126.0"
    ];

    if ($referer) {
        $headers[] = "Referer: $referer";
    }

    if (!empty($additionalHeaders)) {
        $headers = array_merge($headers, $additionalHeaders);
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        return false;
    }
    curl_close($ch);

    return $response;
}

function fetchDataWithCurl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        //error_log('cURL error: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 400) {
        //error_log("HTTP error: $httpCode for URL: $url");
        return false;
    }

    return $response;
}

function primewire_tf($id) {
    global $season, $episode;
    $baseUrl = 'https://primesrc.me/api/v1';

    $cacheDir = __DIR__ . '/cache';
    if (!is_dir($cacheDir)) mkdir($cacheDir, 0777, true);

    $idType = preg_match('/^tt\d+$/', $id) ? 'imdb' : 'tmdb';
    $cacheKey = $idType . '_' . $id;

    $cacheFile = ($season !== null && $episode !== null)
        ? "$cacheDir/primesrc_{$cacheKey}_S{$season}E{$episode}.php"
        : "$cacheDir/primesrc_{$cacheKey}_movie.php";

    if (file_exists($cacheFile) && (time() - filemtime($cacheFile) < 86400)) {
        include $cacheFile;
        return get_defined_vars();
    }

    if ($season !== null && $episode !== null) {
        $apiUrl = "$baseUrl/s?type=tv&$idType=$id&season=$season&episode=$episode";
    } else {
        $apiUrl = "$baseUrl/s?type=movie&$idType=$id";
    }

    $response = fetchDataWithCurl($apiUrl);
    if ($response === false) return false;

    $data = json_decode($response, true);
    if (!$data || !isset($data['servers'])) return [];

    $allowedServers = ['PrimeVid','Voe','Filelions','Streamwish','Vidmoly','Dropload','Dood'];

    foreach ($allowedServers as $srv) {
        ${$srv} = null;
    }

    foreach ($data['servers'] as $server) {
        $name = $server['name'] ?? null;
        $key  = $server['key'] ?? null;
        if (!$name || !$key) continue;
        if (!in_array($name, $allowedServers)) continue;

        $linkUrl = "$baseUrl/l?key=" . urlencode($key);
        $linkResp = fetchDataWithCurl($linkUrl);
        if ($linkResp === false) continue;

        $linkData = json_decode($linkResp, true);
        if (json_last_error() !== JSON_ERROR_NONE) continue;

        $realUrl = $linkData['link'] ?? null;

        if ($realUrl && strpos($realUrl, 'https://streamwish.to') === 0) {
            $realUrl = str_replace('https://streamwish.to', 'https://hlswish.com', $realUrl);
        }

        if ($realUrl && ${$name} === null) {
            ${$name} = $realUrl; 
        }
    }

    $phpCache = "<?php\n";
    foreach ($allowedServers as $srv) {
        $phpCache .= '$' . $srv . ' = ' . var_export(${$srv}, true) . ";\n";
    }
    file_put_contents($cacheFile, $phpCache);

    return get_defined_vars();
}

$result = primewire_tf($tmdbId);

$streamwish = $result['Streamwish'] ?? null;
$voe        = $result['Voe'] ?? null;
$primevid   = $result['PrimeVid'] ?? null;
$filelions  = $result['Filelions'] ?? null;
$dropload  = $result['Dropload'] ?? null;
$vidmoly  = $result['Vidmoly'] ?? null;
$dood  = $result['Dood'] ?? null;

$data[] = array(
    		"vidhide"=>$filelions,
    		"streamwish"=>$streamwish,
			"voesx"=>$voe,
			"dood"=>$dood,
			"vidmoly"=>$vidmoly,
			"dropload"=>$dropload,
			"primevid"=>$primevid,
    	);
$json = json_encode($data);
if ($json === false) {
    $json = json_encode(["jsonError" => json_last_error_msg()]);
    if ($json === false) {
        $json = '{"jsonError":"unknown"}';
    }
    http_response_code(500);
}
echo $json;	
exit;	
?>