<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//set_time_limit(0);

function universalScraper($title, $season, $episode, $type) {
    $baseUrl = 'https://soaper.live';
    $headers = [
        'User-Agent: Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755',
        'Origin: ' . $baseUrl,
        'Referer: ' . $baseUrl,
    ];	
    $searchUrl = $baseUrl . '/search.html?keyword=' . urlencode($title);
	$searchResult = proxiedFetcher($searchUrl, 'GET', null, $headers);

    $dom = new DOMDocument();
    @$dom->loadHTML($searchResult);
    $xpath = new DOMXPath($dom);

    $showLink = null;
    foreach ($xpath->query('//a') as $a) {
        if (trim($a->nodeValue) === $title) {
            $showLink = $a->getAttribute('href');
            break;
        }
    }

    if (!$showLink) {
        //throw new Exception('Content not found for title: ' . htmlspecialchars($title));
    }

    $contentPage = '';

if ($type === 'show') {
    $seasonNumber = (int)$season;  
    $episodeNumber = (int)$episode;

    $showPage = proxiedFetcher($baseUrl . $showLink, 'GET', null, $headers);
    @$dom->loadHTML($showPage);
    $xpath = new DOMXPath($dom);

    $seasonBlock = null;
    $showLink = null;

    foreach ($xpath->query('//h4') as $h4) {
        $seasonText = trim(explode(':', $h4->nodeValue)[0]); 
        if ($seasonText === "Season" . $seasonNumber) {
            $seasonBlock = $h4->parentNode;
            break;
        }
    }

    if (!$seasonBlock) {
        //throw new Exception('Season not found for season number: ' . $seasonNumber);
    }

    foreach ($seasonBlock->childNodes as $child) {
        if ($child->nodeType === XML_ELEMENT_NODE) {
            $episodes = $child->getElementsByTagName('a');
            foreach ($episodes as $episodeElement) {
                $episodeText = trim(explode('.', $episodeElement->nodeValue)[0]); // Remove spaces.
                if ((int)$episodeText === $episodeNumber) {
                    $showLink = $episodeElement->getAttribute('href');
                    break; 
                }
            }
        }
        if ($showLink) break;
    }

    if (!$showLink) {
        //throw new Exception('Episode not found for season: ' . $seasonNumber . ', episode: ' . $episodeNumber);
    }
}
    $headers = [
        'User-Agent: Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755',
        'Origin: ' . $baseUrl,
        'Referer: ' . $baseUrl . $showLink,
    ];
    $contentPage = proxiedFetcher($baseUrl . $showLink, 'GET', null, $headers);
    @$dom->loadHTML($contentPage);
    $xpath = new DOMXPath($dom);
    $passNode = $xpath->query('//*[@id="hId"]')->item(0);
    if (!$passNode) {
        //throw new Exception('Pass node not found in content page');
    }

    $pass = $passNode->getAttribute('value');
	//echo $pass;
    $formData = http_build_query([
        'pass' => $pass,
		'e2' => '0',
        'server' => '0',
    ]);

    $infoEndpoint = ($type === 'show') 
        ? '/home/index/getEInfoAjax' 
        : '/home/index/getMInfoAjax';

    $streamRes = proxiedFetcher($baseUrl . $infoEndpoint, 'POST', $formData, [
	    'User-Agent: Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755',
        'Referer: ' . $baseUrl . $showLink
    ]);

    $streamResJson = json_decode($streamRes, true);

	//if (isset($streamResJson['ip'])) {
    //$streamResJson['ip'] = "0.0.0.0";
    //}
	
	//print_r($streamResJson);
    $ip = $streamResJson['ip'];
    $headers = 'X-Forwarded-For="' . $ip . '"|User-Agent="Mozilla/5.0 (Windows; U; Windows NT 10.5; x64) AppleWebKit/536.48 (KHTML, like Gecko) Chrome/52.0.1321.189 Safari/536.6 Edge/15.14755"|Referer="'.$baseUrl.'"|Origin="'.$baseUrl.'"';
	$encoded_headers = base64_encode($headers);
	$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
	$new_url = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/hls_proxy1.php?url=' . $baseUrl . $streamResJson['val'] . '&data=' . $encoded_headers;
	//echo $new_url;
    $stream = 
        [   
		    'playlist' => $new_url,
        ];

    return [
        'stream' => $stream,
    ];
}

function proxiedFetcher($url, $method = 'GET', $postData = null, $headers = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    }
    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function curlRequest($url, $options = []) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 

    if (isset($options['method']) && strtoupper($options['method']) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $options['body']);
    }

    if (isset($options['headers'])) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $options['headers']);
    }

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

function getTitleAndYear($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $isMovie = false;
    $title = '';
    $year = '';

    $externalUrl = $baseUrl . "find/" . $id . "?api_key=" . $apiKey . "&external_source=imdb_id";
    $externalResponse = file_get_contents($externalUrl);
    $externalData = json_decode($externalResponse, true);

    if (isset($externalData['movie_results'][0]['id'])) {
        $tmdbId = $externalData['movie_results'][0]['id'];
        $isMovie = true;
    } elseif (isset($externalData['tv_results'][0]['id'])) {
        $tmdbId = $externalData['tv_results'][0]['id'];
    } else {
        return null;
    }

    if ($isMovie) {
        $movieUrl = $baseUrl . "movie/" . $tmdbId . "?api_key=" . $apiKey;
        $movieResponse = file_get_contents($movieUrl);
        $movieData = json_decode($movieResponse, true);

        if (isset($movieData['id'])) {
            $title = $movieData['title'];
            $year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
        }
    } else {
        $tvUrl = $baseUrl . "tv/" . $tmdbId . "?api_key=" . $apiKey;
        $tvResponse = file_get_contents($tvUrl);
        $tvData = json_decode($tvResponse, true);

        if (isset($tvData['id'])) {
        $title = $tvData['name'];
        $year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
        }
    }

    if (!empty($title)) {
        return [
            'title' => $title,
            'year' => $year
        ];
    } else {
        return null;
    }
}

function getTitleAndYearTmdb($id, $season = null, $episode = null) {
    $apiKey = '05902896074695709d7763505bb88b4d';
    $baseUrl = 'https://api.themoviedb.org/3/';
    $title = '';
    $year = '';
    if ($season && $episode) {
    $Url = $baseUrl . "tv/" . $id . "?api_key=" . $apiKey;
	$tvResponse = file_get_contents($Url);
    $tvData = json_decode($tvResponse, true);
    $title = $tvData['name']; 
	$year = isset($tvData['first_air_date']) ? substr($tvData['first_air_date'], 0, 4) : '';
	} else {
	$Url = $baseUrl . "movie/" . $id . "?api_key=" . $apiKey;
	$movieResponse = file_get_contents($Url);
    $movieData = json_decode($movieResponse, true);
    $title = $movieData['title']; 
	$year = isset($movieData['release_date']) ? substr($movieData['release_date'], 0, 4) : '';
	}	
    if (!empty($title)) {
        return [
            'title' => $title,
            'year' => $year
        ];
	} else {
        return null;
    }
}

function isImdbId($id) {
    return preg_match('/^tt\d{7,9}$/', $id);
}

$id = isset($_GET['id']) ? $_GET['id'] : null;
$season = isset($_GET['season']) ? $_GET['season'] : null;
$episode = isset($_GET['episode']) ? $_GET['episode'] : null;

if (!$id) {
    echo json_encode(['error' => 'ID is required.']);
    exit;
}

if (isImdbId($id)) {
$call = getTitleAndYear($id, $season, $episode);
} else {
$call = getTitleAndYearTmdb($id, $season, $episode);
}

if ($call) {
$title = $call['title'];
}

try {
    header('Content-Type: application/json');
    
    if (!empty($season) && !empty($episode)) {
        $output = universalScraper($title, $season, $episode, "show");
    } else {
        $output = universalScraper($title, null, null, "movie");
    }    
	
	$jsonOutput = json_encode($output['stream'], JSON_PRETTY_PRINT);

    echo $jsonOutput;
    exit();
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage()
    ]);
}
