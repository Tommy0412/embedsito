<?php
function getFullLanguageName($languageCode) {
    $languageMap = [
        'en' => 'English',
        'fr' => 'French',
        'es' => 'Spanish',
        'de' => 'German',
        'it' => 'Italian',
        'pt' => 'Portuguese',
        'ru' => 'Russian',
        'zh' => 'Chinese',
        'ja' => 'Japanese',
        'ko' => 'Korean',
        'ar' => 'Arabic',
        'hi' => 'Hindi',
        'bn' => 'Bengali',
        'pa' => 'Punjabi',
        'ta' => 'Tamil',
        'te' => 'Telugu',
        'mr' => 'Marathi',
        'ur' => 'Urdu',
        'gu' => 'Gujarati',
        'kn' => 'Kannada',
        'or' => 'Odia',
        'ml' => 'Malayalam',
        'sa' => 'Sanskrit',
        'ne' => 'Nepali',
        'si' => 'Sinhala',
        'my' => 'Burmese',
        'km' => 'Khmer',
        'th' => 'Thai',
        'lo' => 'Lao',
        'vi' => 'Vietnamese',
        'id' => 'Indonesian',
        'ms' => 'Malay',
        'tl' => 'Tagalog',
        'sw' => 'Swahili',
        'zu' => 'Zulu',
        'xh' => 'Xhosa',
        'af' => 'Afrikaans',
        'nl' => 'Dutch',
        'sv' => 'Swedish',
        'no' => 'Norwegian',
        'da' => 'Danish',
        'fi' => 'Finnish',
        'pl' => 'Polish',
        'cs' => 'Czech',
        'sk' => 'Slovak',
        'hu' => 'Hungarian',
        'ro' => 'Romanian',
        'bg' => 'Bulgarian',
        'el' => 'Greek',
        'tr' => 'Turkish',
        'he' => 'Hebrew',
        'fa' => 'Persian',
        'ps' => 'Pashto',
        'ku' => 'Kurdish',
        'sd' => 'Sindhi',
        'ug' => 'Uyghur',
        'bo' => 'Tibetan',
        'dz' => 'Dzongkha',
        'mn' => 'Mongolian',
        'ka' => 'Georgian',
        'hy' => 'Armenian',
        'az' => 'Azerbaijani',
        'kk' => 'Kazakh',
        'uz' => 'Uzbek',
        'tk' => 'Turkmen',
        'ky' => 'Kyrgyz',
        'tg' => 'Tajik',
        'be' => 'Belarusian',
        'uk' => 'Ukrainian',
        'sr' => 'Serbian',
        'hr' => 'Croatian',
        'sl' => 'Slovene',
        'mk' => 'Macedonian',
        'sq' => 'Albanian',
        'bs' => 'Bosnian',
        'mt' => 'Maltese',
        'ga' => 'Irish',
        'cy' => 'Welsh',
        'br' => 'Breton',
        'gd' => 'Scottish Gaelic',
        'gv' => 'Manx',
        'kw' => 'Cornish',
        'is' => 'Icelandic',
        'fo' => 'Faroese',
        'kl' => 'Greenlandic',
        'iu' => 'Inuktitut',
        'cr' => 'Cree',
        'oj' => 'Ojibwe',
        'yi' => 'Yiddish',
        'lb' => 'Luxembourgish',
        'fy' => 'Frisian',
        'wa' => 'Walloon',
        'co' => 'Corsican',
        'sc' => 'Sardinian',
        'rm' => 'Romansh',
        'ln' => 'Lingala',
        'lg' => 'Ganda',
        'ny' => 'Chichewa',
        'sn' => 'Shona',
        'st' => 'Sotho',
        'tn' => 'Tswana',
        'ts' => 'Tsonga',
        've' => 'Venda',
        'ss' => 'Swati',
        'nr' => 'Ndebele',
        'xh' => 'Xhosa',
        'zu' => 'Zulu',
        'ha' => 'Hausa',
        'yo' => 'Yoruba',
        'ig' => 'Igbo',
        'ff' => 'Fulah',
        'rn' => 'Rundi',
        'rw' => 'Kinyarwanda',
        'mg' => 'Malagasy',
        'om' => 'Oromo',
        'so' => 'Somali',
        'ti' => 'Tigrinya',
        'am' => 'Amharic',
        'aa' => 'Afar',
        'ss' => 'Swati',
        'nr' => 'Ndebele',
        'xh' => 'Xhosa',
        'zu' => 'Zulu',
        'ha' => 'Hausa',
        'yo' => 'Yoruba',
        'ig' => 'Igbo',
        'ff' => 'Fulah',
        'rn' => 'Rundi',
        'rw' => 'Kinyarwanda',
        'mg' => 'Malagasy',
        'om' => 'Oromo',
        'so' => 'Somali',
        'ti' => 'Tigrinya',
        'am' => 'Amharic',
        'aa' => 'Afar',
    ];

    $languageCode = strtolower($languageCode);

    if (isset($languageMap[$languageCode])) {
        return $languageMap[$languageCode];
    }

    return 'Unknown Language';
}

function handleRequest($requestUrl) {
    $urlParts = parse_url($requestUrl);
    parse_str($urlParts['query'] ?? '', $queryParams);

    $id = $queryParams['id'] ?? null;
    $season = $queryParams['season'] ?? null;
    $episode = $queryParams['episode'] ?? null;

    if (!$id) {
        return jsonResponse(['error' => 'ID is required.'], 400);
    }

    $imdbId = preg_match('/^tt\d{7}$/', $id) ? $id : fetchImdbId($id, $season, $episode);

    if (!$imdbId) {
        return jsonResponse(['error' => 'IMDb ID not found for the provided TMDB ID.'], 404);
    }

    return handleSubtitleRequest($imdbId, $season, $episode, $queryParams['languages'] ?? null);
}

function handleSubtitleRequest($imdbId, $season, $episode, $languagesParam)
{
    $defaultLanguages = ['en', 'fr', 'es', 'de', 'pt', 'it', 'ar', 'hr', 'sr', 'ba', 'bg', 'ro'];
    $languages = $languagesParam ? explode(',', $languagesParam) : $defaultLanguages;

    $results = [];
    foreach ($languages as $language) {
        $apiUrl = "https://fsharetv.co/api/subtitle/$imdbId";

        if ($season && $episode) {
            $apiUrl .= "?season_number=$season&episode_number=$episode&languages=$language";
        } else {
            $apiUrl .= "?languages=$language";
        }

        $response = fetchApi($apiUrl);
        if ($response['status'] !== 200) {
            return jsonResponse(['error' => $response['error']], 500);
        }

        $data = json_decode($response['data'], true);
        if (!empty($data['data'])) {
            foreach ($data['data'] as $subtitle) {
                $attributes = $subtitle['attributes'];
				$lang = getFullLanguageName($attributes['language']);
                //$letterlang = $attributes['language'];

                foreach ($attributes['files'] as $file) {
					$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
					$downloadUrl = $scheme . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . "/cors_proxy.php?url=";
                    if ($file['cd_number'] == 1) {
						$subtitleUrl = "https://fsharetv.co/api/subtitles/{$file['file_id']}.vtt";
                        $results[] = [
							'file' => $downloadUrl . urlencode($subtitleUrl), 
                            'label' => "$lang - {$file['file_name']}",
                            'kind' => 'captions'
                        ];
                    }
                }
            }
        }
    }

    return jsonResponse($results, 200);
}

function fetchImdbId($id, $season, $episode) {
    $tmdbApiKey = '05902896074695709d7763505bb88b4d';
    $tmdbUrl = $season && $episode
        ? "https://api.themoviedb.org/3/tv/$id/external_ids?api_key=$tmdbApiKey&language=en-US"
        : "https://api.themoviedb.org/3/movie/$id/external_ids?api_key=$tmdbApiKey&language=en-US";

    $response = fetchApi($tmdbUrl);
    if ($response['status'] !== 200) {
        return null;
    }

    $data = json_decode($response['data'], true);
    return $data['imdb_id'] ?? null;
}

function fetchApi($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept: application/json',
        'Origin: https://fsharetv.co',
        'Referer: https://fsharetv.co/'
    ]);

    $data = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    return $status === 200 ? ['status' => 200, 'data' => $data] : ['status' => $status, 'error' => $error];
}

function jsonResponse($data, $status = 200)
{
    header('Content-Type: application/json', true, $status);
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

handleRequest($_SERVER['REQUEST_URI']);