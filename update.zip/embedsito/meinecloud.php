<?php
$id = isset($_GET["id"]) ? $_GET["id"] : null;

function getImdbIdFromTmdb($tmdbId, $apiKey) {
    $url = "https://api.themoviedb.org/3/movie/{$tmdbId}?api_key={$apiKey}";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json'
    ]);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        error_log("cURL Error: " . curl_error($ch));
        curl_close($ch);
        return null;
    }
    curl_close($ch);

    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE || !isset($data['imdb_id'])) {
        error_log("Error: Invalid JSON response or IMDb ID not found.");
        return null;
    }

    return $data['imdb_id'];
}

function fetchMovieLinks($url) {
    $html = fetchData($url);
    if ($html === false) {
        die("Failed to fetch the content from the URL: $url");
    }

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML($html);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);

    $divNodes = $xpath->query('//div[contains(@class, "_hidden-mirrors")]/li');
    $ulNodes = $xpath->query('//ul[contains(@class, "_player-mirrors")]/li');

    $links = [];

    function extractLinks($nodes) {
        $links = [];
        foreach ($nodes as $node) {
            $dataLink = $node->getAttribute('data-link');
            if ($dataLink) {
                if (strpos($dataLink, '//') === 0) {
                    $dataLink = 'https:' . $dataLink;
                }
                $links[] = $dataLink;
            }
        }
        return $links;
    }

    $links = array_merge($links, extractLinks($divNodes));
    $links = array_merge($links, extractLinks($ulNodes));

    return $links;
}

function fetchData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function getHost($url) {
    $parsedUrl = parse_url($url);
    return $parsedUrl['host'] ?? '';
}

$apiKey = "1428c4185bce6abd6564049d1351970d";

$imdbId = getImdbIdFromTmdb($id, $apiKey);

$pageUrl = 'https://meinecloud.click/movie/'.$imdbId.'';
$movieLinks = fetchMovieLinks($pageUrl);

$hostedLinks = [];
foreach ($movieLinks as $link) {
    $hostedLinks[] = [
        'host' => getHost($link),
        'url' => $link
    ];
}

header('Content-Type: application/json');
echo json_encode($hostedLinks, JSON_PRETTY_PRINT);
exit();
?>