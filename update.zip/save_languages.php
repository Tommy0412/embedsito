<?php
header('Content-Type: text/plain');

$languageMap = [
    'en' => 'English', 'fr' => 'French', 'es' => 'Spanish', 'de' => 'German', 'it' => 'Italian',
    'pt' => 'Portuguese', 'ru' => 'Russian', 'zh' => 'Chinese', 'ja' => 'Japanese', 'ko' => 'Korean',
    'ar' => 'Arabic', 'hi' => 'Hindi', 'bn' => 'Bengali', 'pa' => 'Punjabi', 'ta' => 'Tamil',
    'te' => 'Telugu', 'mr' => 'Marathi', 'ur' => 'Urdu', 'gu' => 'Gujarati', 'kn' => 'Kannada',
    'ml' => 'Malayalam', 'sa' => 'Sanskrit', 'ne' => 'Nepali', 'my' => 'Burmese', 'km' => 'Khmer',
    'th' => 'Thai', 'lo' => 'Lao', 'vi' => 'Vietnamese', 'id' => 'Indonesian', 'ms' => 'Malay',
    'tl' => 'Tagalog', 'sw' => 'Swahili', 'zu' => 'Zulu', 'xh' => 'Xhosa', 'af' => 'Afrikaans',
    'nl' => 'Dutch', 'sv' => 'Swedish', 'no' => 'Norwegian', 'da' => 'Danish', 'fi' => 'Finnish',
    'pl' => 'Polish', 'cs' => 'Czech', 'sk' => 'Slovak', 'hu' => 'Hungarian', 'ro' => 'Romanian',
    'bg' => 'Bulgarian', 'el' => 'Greek', 'tr' => 'Turkish', 'he' => 'Hebrew', 'fa' => 'Persian',
    'ps' => 'Pashto', 'ku' => 'Kurdish', 'mn' => 'Mongolian', 'ka' => 'Georgian', 'hy' => 'Armenian',
    'az' => 'Azerbaijani', 'kk' => 'Kazakh', 'uz' => 'Uzbek', 'tk' => 'Turkmen', 'ky' => 'Kyrgyz',
    'tg' => 'Tajik', 'be' => 'Belarusian', 'uk' => 'Ukrainian', 'sr' => 'Serbian', 'hr' => 'Croatian',
    'sl' => 'Slovene', 'mk' => 'Macedonian', 'sq' => 'Albanian', 'bs' => 'Bosnian', 'mt' => 'Maltese',
    'ga' => 'Irish', 'cy' => 'Welsh', 'br' => 'Breton', 'gd' => 'Scottish Gaelic', 'is' => 'Icelandic',
    'kl' => 'Greenlandic', 'yi' => 'Yiddish', 'lb' => 'Luxembourgish', 'so' => 'Somali',
];

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!isset($data['langs']) || !is_array($data['langs'])) {
    http_response_code(400);
    echo "Invalid data";
    exit;
}

$selected = array_intersect(array_keys($languageMap), $data['langs']);

if (count($selected) === 0) {
    http_response_code(400);
    echo "Please select at least one language.";
    exit;
}

$iniContent = "[Languages]\ndefault = " . implode(',', $selected) . "\n";

if (file_put_contents(__DIR__ . '/languages.ini', $iniContent) !== false) {
    echo "Languages saved!";
} else {
    http_response_code(500);
    echo "Failed to save languages.ini";
}