<?php
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json');

try {
    $downloadUrl = 'https://raw.githubusercontent.com/Tommy0412/embedsito/master/update.zip';
    $zipFilePath = __DIR__ . '/download.zip';
    $extractDir = realpath(__DIR__ . '/../');
    
	$preserve = [
    'updater',
    'updater/version.txt',
    'updater/versionCheck.php',
    'updater/performUpdate.php'
    ];
	
    clearDirectory($extractDir, $preserve);

    downloadZip($downloadUrl, $zipFilePath);
    if (extractZip($zipFilePath, $extractDir)) {
        unlink($zipFilePath);  
        echo json_encode(['success' => true, 'message' => 'Update completed successfully.']);
    } else {
        throw new Exception('Failed to extract the update.');
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function downloadZip($url, $zipFilePath) {
    $ch = curl_init($url);
    $fp = fopen($zipFilePath, 'w+');
    if (!$fp) {
        throw new Exception("Failed to open file for writing: $zipFilePath");
    }

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_exec($ch);

    if (curl_errno($ch)) {
        throw new Exception("CURL Error: " . curl_error($ch));
    }

    curl_close($ch);
    fclose($fp);

    if (!file_exists($zipFilePath)) {
        throw new Exception("ZIP file not found after download: $zipFilePath");
    }
}

function extractZip($zipFilePath, $extractDir) {
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) === TRUE) {
        $zip->extractTo($extractDir);
        $zip->close();
        return true;
    }
    return false;
}

function clearDirectory($dir, $preserve = []) {
    $items = array_diff(scandir($dir), ['.', '..']);

    foreach ($items as $item) {
        $path = $dir . DIRECTORY_SEPARATOR . $item;

        if (in_array($item, $preserve)) {
            continue;
        }

        if (is_dir($path)) {
            clearDirectory($path, $preserve);
            @rmdir($path);
        } else {
            @unlink($path);
        }
    }
}

?>