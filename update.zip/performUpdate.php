<?php
ini_set('display_errors', 0);
error_reporting(0);
header('Content-Type: application/json');

try {
    $downloadUrl = 'https://raw.githubusercontent.com/Tommy0412/embedsito/master/update.zip';
    $zipFilePath = __DIR__ . '/download.zip';
    $extractDir = __DIR__;

    // Clear the current folder before unpacking
    clearDirectory($extractDir);

    // Download and extract the zip file
    downloadZip($downloadUrl, $zipFilePath);
    if (extractZip($zipFilePath, $extractDir)) {
        unlink($zipFilePath);  // Remove the zip file after extraction
        echo json_encode(['success' => true, 'message' => 'Update completed successfully.']);
    } else {
        throw new Exception('Failed to extract the update.');
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function downloadZip($url, $zipFilePath) {
    $ch = curl_init($url);
    $fp = fopen($zipFilePath, 'w+');
    if (!$fp) {
        throw new Exception("Failed to open file for writing: $zipFilePath");
    }

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_exec($ch);

    if (curl_errno($ch)) {
        throw new Exception("CURL Error: " . curl_error($ch));
    }

    curl_close($ch);
    fclose($fp);

    if (!file_exists($zipFilePath)) {
        throw new Exception("ZIP file not found after download: $zipFilePath");
    }
}

function extractZip($zipFilePath, $extractDir) {
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) === TRUE) {
        $zip->extractTo($extractDir);
        $zip->close();
        return true;
    }
    return false;
}

// Function to clear the current directory
function clearDirectory($dir) {
    // Get all files and directories inside the given directory
    $files = array_diff(scandir($dir), array('.', '..'));

    // Loop through the files and directories
    foreach ($files as $file) {
        $filePath = $dir . DIRECTORY_SEPARATOR . $file;

        // If it's a directory, recursively delete its contents
        if (is_dir($filePath)) {
            clearDirectory($filePath);
            rmdir($filePath);  // Remove the directory
        } else {
            unlink($filePath);  // Remove the file
        }
    }
}
?>