<?php
$docRoot = is_string(getenv('PHP_CLI_SERVER_WORKERS')) ? getcwd() : __DIR__;
$uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
$decodedPath = rawurldecode($uriPath);

if ($decodedPath === false || str_contains($decodedPath, "\0") || preg_match('#/(?:\.|%2e)#i', $decodedPath)) {
	http_response_code(404);
	echo 'Not Found';
	exit;
}

$target = $docRoot . $decodedPath;

if (is_file($target)) {
	return false; 
}

if (is_dir($target)) {
	$indexInDir = rtrim($target, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'index.html';
	if (is_file($indexInDir)) {
		require $indexInDir;
		exit;
	}

	http_response_code(404);
	echo 'Not Found';
	exit;
}

$frontController = $docRoot . '/index.html';
if (is_file($frontController)) {
	$_SERVER['SCRIPT_NAME'] = '/index.html';
	$_SERVER['PHP_SELF'] = '/index.html';
	require $frontController;
	exit;
}

http_response_code(404);
echo 'Not Found';